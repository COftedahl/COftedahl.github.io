Run project with "npm start"

# test string: abc def ghi\naab aba abb\naaa bbb ccc\nbaa bab bba\nace car cab\nash arc ape\naid ail aim\narm all\nbar bet bat\nban bam ball\ncam car cash
# test url: https://coftedahl.github.io/