import { useEffect } from "react";

interface Theme {
  [key: string]: string;//allows indexing of the values in Theme

  SVGIconColor: string, 
  CalendarHeight: string, 
  TextInputAreaHeight: string, 
}

const standardBoxShadow: string = "0.0px 1.0px 3.0px 0px rgba(0, 0, 0, 0.3), 0.0px 4.0px 8.0px 3.0px rgba(0, 0, 0, 0.15)";
const standardBorderRadius: string = "16px";

export const Theme: Theme = {
  
  SVGIconColor: "black", 
  CalendarHeight: "max-content", 
  TextInputAreaHeight: "max-content", 
}

const ThemeComponent = () => {

  const initializeCSSVariables = () => {
    document.documentElement.style.setProperty("--standardBoxShadow", standardBoxShadow);
    document.documentElement.style.setProperty("--standardBorderRadius", standardBorderRadius);

    for (let x in Theme) {
      document.documentElement.style.setProperty("--" + x, Theme[x]);
    }
  };

  useEffect(() => {
    if (!document.documentElement.style.getPropertyValue("--standardBoxShadow")) {
      initializeCSSVariables();
    }
  }, []);

  return (
    <>
    </>
  );
}

export default ThemeComponent;