import type { ChangeEvent } from "react";
import './InputBar.css';

interface InputBarProps {
  containerClassName?: string, 
  labelText?: string, 
  labelClassName?: string, 
  inputClassName?: string, 
  buttonText?: string, 
  buttonClassName?: string, 
  buttonOnClick?: () => void, 
  inputValue?: string, 
  inputPlaceholder?: string, 
  inputOnChange?: (e: ChangeEvent) => void, 
  autocompleteOptions?: string[], 
  autocompleteListName?: string, 
  hideButton?: boolean
}

const InputBar: React.FC<InputBarProps> = (props: InputBarProps) => {

  const content: React.ReactElement = (
    <>
    <datalist id={props.autocompleteListName}>
      {
        props.autocompleteOptions ? 
        props.autocompleteOptions.map((option: string, index: number) => {
          return (
            <option key={index}>{option}</option>
          )
        })
        : <></>
      }
    </datalist>
    <input 
      type="text" 
      className={(props.inputClassName ?? "") + " input InputBar_Input"}
      placeholder={(props.inputPlaceholder ?? "")}
      value={props.inputValue ?? ""}
      onChange={props.inputOnChange ?? ((_e: ChangeEvent) => {})}
      list={props.autocompleteListName}
    />
    {
      ((props.hideButton === undefined) || (props.hideButton === false)) &&
      <button 
        type="button" 
        className={(props.buttonClassName ?? "") + " button"}
        onClick={props.buttonOnClick ?? (() => {})}
      >
        {(props.buttonText ?? "")}
      </button>
    }
    </>
  );

  return (
    <>
    {
      (props.labelText && props.labelText.length > 0) || (props.labelClassName && props.labelClassName.length > 0) ?
        <label className={(props.containerClassName ?? "") + " border borderRadius padding05 borderBox flexRow fullWidth"}>
          {(props.labelText !== undefined && props.labelText.length > 0) ? 
            <p className={((props.labelClassName && props.labelClassName.length > 0) ? props.labelClassName : "") + " flexColumn centerJustify padding05"}>
              {props.labelText}
            </p>
          : 
            ""
          }
          {content}
        </label>
      : 
        <div className={(props.containerClassName ?? "") + " border borderRadius padding05 borderBox flexRow fullWidth"}>
          {content}
        </div>
    }
    </>
  );
}

export default InputBar;