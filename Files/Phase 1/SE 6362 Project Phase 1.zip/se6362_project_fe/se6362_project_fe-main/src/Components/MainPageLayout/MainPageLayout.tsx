import { Outlet } from "react-router-dom";
import NavBar, { type Tab } from "./NavBar/NavBar";
import './MainPageLayout.css';

interface MainPageLayoutProps {
  tabs: Tab[], 
  children?: React.ReactNode
}

const MainPageLayout: React.FC<MainPageLayoutProps> = (props: MainPageLayoutProps) => {

  return (
    <div className="MainPageLayoutDiv fullWidth fullHeight flexColumn">
      <NavBar tabs={props.tabs}/>
      <div className="MainPageLayout_ContentDiv padding05 borderBox fullWidth">
        <Outlet/>
      </div>
    </div>
  );
}

export default MainPageLayout;