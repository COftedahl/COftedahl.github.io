import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import InputBar from '../../../Utility/InputBar/InputBar';
import { BACKEND_URL, KWIC_AUTOCOMPLETES, KWIC_ROUTE, KWIC_SEARCH_RESULTS } from '../../../Constants/backendroutes';
import { FETCH_POST_OPTIONS } from '../../../Constants/fetchCallHeaders';

interface SearchPageProps {

}

const SearchPage: React.FC<SearchPageProps> = (_props: SearchPageProps) => {

  const [autocompleteOptions, setAutocompleteOptions] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState<string>("");
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [_hasSearched, setHasSearched] = useState<boolean>(false);

  const handleInputChange = (e: ChangeEvent) => {
    setInputValue((e.target as any).value)
  }

  const getSearchResults = async () => {
    return await fetch(BACKEND_URL + KWIC_ROUTE + KWIC_SEARCH_RESULTS, {
      method: "POST", 
      body: JSON.stringify({searchString: inputValue}), 
      ...FETCH_POST_OPTIONS, 
    }).then((res) => res.json());
  }

  const handleSearchClicked = async (e?: FormEvent) => {
    if (e) {
      e.preventDefault();
    }
    setHasSearched(true);
    const results = await getSearchResults();
    setSearchResults(results);
  }

  const getAutocompleteOptions = async () => {
    if (autocompleteOptions.length < 1) {
      console.log("Fetching autocompletes");
      const result: string[] = await fetch(BACKEND_URL + KWIC_ROUTE + KWIC_AUTOCOMPLETES, {
        method: "GET"
      }).then((res) => res.json());
      setAutocompleteOptions(result);
    }
  }
  
  useEffect(() => {
    getAutocompleteOptions();
  }, [])

  return (
    <div className="SearchDiv flexColumn fullHeight fullWidth">
      <form action="" onSubmit={handleSearchClicked}>
        <InputBar
          containerClassName="Search_Searchbar"
          inputClassName="Search_Searchbar_Input"
          inputPlaceholder="enter search text here"
          buttonText="Search"
          buttonClassName="Search_Searchbar_Button"
          autocompleteListName="SearchbarOptions"
          autocompleteOptions={autocompleteOptions}
          inputValue={inputValue}
          inputOnChange={handleInputChange}
          buttonOnClick={handleSearchClicked}
        />
      </form>
      {
        searchResults.map((url: string, index: number) => {
          return (
            <a key={index} href={url}>
              {url}
            </a>
          )
        })
      }
    </div>
  );
}

export default SearchPage;