import Window from "./Window/Window";
import InputBar from "../../../Utility/InputBar/InputBar";
import { useState, type ChangeEvent, type FormEvent } from "react";
import { lineDelimiterText } from "../../../Constants/delimiters";
import WSHandler, { type IWSWindowContent } from "./WSHandler";
import { BACKEND_URL, BACKEND_WS_URL, KWIC_REAL_TIME_VIEWER, KWIC_ROUTE, KWIC_WSS_PORT } from "../../../Constants/backendroutes";
import { FETCH_POST_OPTIONS } from "../../../Constants/fetchCallHeaders";
import './ComputeShiftsPage.css';
import { useNavigate } from "react-router-dom";
import { saveCircularShiftsParams_lines, saveCircularShiftsRoute } from "../../../Constants/frontendroutes";

interface ComputeShiftsPageProps {

}

const ComputeShiftsPage: React.FC<ComputeShiftsPageProps> = (_props: ComputeShiftsPageProps) => {

  const navigate = useNavigate();

  const numColors: number = 5;
  const [inputValue, setInputValue] = useState<string>("");
  const [window1Value, setWindow1Value] = useState<IWSWindowContent[]>([]);
  const [window2Value, setWindow2Value] = useState<IWSWindowContent[]>([]);
  const [window3Value, setWindow3Value] = useState<IWSWindowContent[]>([]);
  const [wsConnection, setWSConnection] = useState<WSHandler | null>(null);

  const handleInputChanged = (e: ChangeEvent) => {
    setInputValue((e.target as any).value);
  }

  const handleComputeShiftsClicked = async (e?: FormEvent) => {
    if (e) {
      e.preventDefault();
    }

    const wssPort = await fetch (BACKEND_URL + KWIC_ROUTE + KWIC_WSS_PORT, {
      method: "GET"
    }).then((res) => res.json());

    const sendComputeShiftsRequest = async () => {
      fetch (BACKEND_URL + KWIC_ROUTE + KWIC_REAL_TIME_VIEWER, {
        method: "POST", 
        body: JSON.stringify({unshiftedString: inputValue}), 
        ...FETCH_POST_OPTIONS, 
      });
    }
    if (wsConnection) {
      wsConnection.close();
      setWSConnection(null);
    }
    setWindow1Value([]);
    setWindow2Value([]);
    setWindow3Value([]);
    setWSConnection(new WSHandler(BACKEND_WS_URL + ":" + wssPort, [setWindow1Value, setWindow2Value, setWindow3Value], sendComputeShiftsRequest));
  }

  const handleSaveShiftsClicked = () => {
    navigate(saveCircularShiftsRoute + "?" + saveCircularShiftsParams_lines + "=" + encodeURIComponent(inputValue));
  }

  return (
  <div className="ComputeShiftsPage flexColumn fullHeight fullWidth">
    <div className="ComputeShifts_InputDiv fullWidth flexRow padding05 borderBox">
      <form className="fullWidth" onSubmit={handleComputeShiftsClicked}>
        <InputBar
          containerClassName="ComputeShifts_InputBar"
          labelText={"Lines to be shifted (separate lines with " + lineDelimiterText + "): "}
          labelClassName="ComputeShifts_Input_Label_Text"
          buttonText="Compute Shifts"
          inputPlaceholder="Enter lines to shift here"
          buttonOnClick={handleComputeShiftsClicked}
          inputValue={inputValue}
          inputOnChange={handleInputChanged}
        />
      </form>
      {/* <label className="ComputeShifts_Input_Label label fullWidth flexRow">
        <p className="ComputeShifts_Input_Label_Text padding05">
          Lines to be shifted: 
        </p>
        <input 
          className="ComputeShifts_Input_InputField input textAlignLeft"
          type="text"
          placeholder="Enter lines to shift here"
        />
      </label> */}
    </div>
    <div className="ComputeShifts_OutputDiv fullWidth flexGrow1 flexRow overflowAuto">
      <div className="ComputeShifts_LeftDiv flexColumn flexGrow1 overflowAuto">
        <Window sizingClassName={"ComputeShifts_Left_CurrentLineWindow ComputeShifts_Window borderBox padding1"} stylingClassName={"card"} title={"Currently Shifting Line"}>
          {window1Value.map((item: IWSWindowContent, index: number) => {
            return (
              <p className={"ComputeShifts_WindowText_color" + ((item.colorIndex % numColors) + 1)} key={index}>
                {item.content}
              </p>
            )
          })}
        </Window>
        <Window sizingClassName={"ComputeShifts_Left_CurrentShiftsWindow borderBox flexGrow1 padding1 overflowAuto"} stylingClassName={"card"} title={"Shifted Lines"}>
          {window2Value.map((item: IWSWindowContent, index: number, arr: IWSWindowContent[]) => {
            return (
              <div key={index}>
              {(index > 0 && arr[index - 1].colorIndex !== item.colorIndex) && 
                <br key={index + arr.length}/>
              }
              <p className={"ComputeShifts_WindowText_color" + ((item.colorIndex % numColors) + 1)} key={index}>
                {item.content}
              </p>
              </div>
            )
          })}
        </Window>
      </div>
      <div className="ComputeShifts_RightDiv flexColumn flexGrow1">
        <Window sizingClassName={"ComputeShifts_Right_AlphabetizedWindow ComputeShifts_Window borderBox flexGrow1 padding1 overflowAuto"} stylingClassName={"card"} title={"Sorted Lines"}>
          {window3Value.map((item: IWSWindowContent, index: number) => {
            return (
              <p className={"ComputeShifts_WindowText_color" + ((item.colorIndex % numColors) + 1)} key={index}>
                {item.content}
              </p>
            )
          })}
        </Window>
      </div>
    </div>
    <div className="ComputeShifts_SaveDiv flexRow fullWidth padding05 borderBox centerJustify">
      <button className="ComputeShifts_SaveShiftsButton button wideButton" onClick={handleSaveShiftsClicked}>
        Save Shifts
      </button>
    </div>
  </div>
  )
}

export default ComputeShiftsPage;