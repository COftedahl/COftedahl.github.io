
export interface IWSWindowContent {
    content: string, 
    colorIndex: number, 
}

export interface IWSMessage {
  windowIndex: 0 | 1 | 2, 
  newWindowContent: IWSWindowContent[], 
}

class WSHandler {
  private ws: WebSocket | null;
  public close: () => void;

  constructor(target: string, windowContentsCallbacks: React.Dispatch<React.SetStateAction<IWSWindowContent[]>>[], onOpenCallback: () => void) {
    this.ws = new WebSocket(target);

    this.close = () => {
      if (this.ws) {
        this.ws.close();
      }
    }
    
    // this.ws.on("connection", () => {
    this.ws.onopen = () => {
      onOpenCallback();
      if (this.ws) {
        // this.ws.on("message", (message: IWSMessage) => {
        this.ws.onmessage = (messageEvent: MessageEvent) => {
          const message: IWSMessage = JSON.parse(messageEvent.data);
          windowContentsCallbacks[message.windowIndex](message.newWindowContent);
        };
        // this.ws.on("close", () => {
        this.ws.onclose = () => {
          this.ws = null;
        }
      }
    }
  }
}

export default WSHandler;