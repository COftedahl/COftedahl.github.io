import ThemeComponent from './Utility/Theme/Theme'
import MainPageLayout from './Components/MainPageLayout/MainPageLayout'
import type { Tab } from './Components/MainPageLayout/NavBar/NavBar'
import { errorRoute, saveCircularShiftsRoute, searchRoute, viewCircularShiftsRoute } from './Constants/frontendroutes'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import SearchPage from './Components/Tabs/Search/SearchPage'
import ComputeShiftsPage from './Components/Tabs/ComputeShifts/ComputeShiftsPage'
import ErrorPage from './Components/Tabs/ErrorPage/ErrorPage'
import './App.css'
import './universalstyles.css'
import SaveShiftsPage from './Components/Tabs/StoreShifts/StoreShiftsPage'

function App() {

  const tabs: Tab[] = [
    {
      name: 'Search',
      route: searchRoute, 
    }, 
    {
      name: 'Compute Shifts',
      route: viewCircularShiftsRoute, 
    }, 
    {
      name: 'Save Shifts',
      route: saveCircularShiftsRoute, 
    }
  ];

  return (
    <>
      <ThemeComponent/>
      <BrowserRouter>
        <Routes>
          <Route element={<MainPageLayout tabs={tabs}/>}>
            <Route index element={<SearchPage/>}/>
            <Route path={viewCircularShiftsRoute} element={<ComputeShiftsPage/>}/>
            <Route path={saveCircularShiftsRoute} element={<SaveShiftsPage/>}/>
            <Route path={errorRoute} element={<ErrorPage/>}/>
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
