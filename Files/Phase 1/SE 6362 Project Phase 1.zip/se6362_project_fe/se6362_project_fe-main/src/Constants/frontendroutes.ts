export const searchRoute = "/";
export const viewCircularShiftsRoute = "/shift";
export const saveCircularShiftsRoute = "/save";
export const saveCircularShiftsParams_lines = "lines";
export const errorRoute = "*";