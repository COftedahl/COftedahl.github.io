import express from 'express';
import cors from 'cors';
import testRouter from './src/Routers/testRouter';
import kwicRouter from './src/Routers/kwicRouter';
import dotenv from "dotenv";
import mongoose from "mongoose";

const appRouter = express();

appRouter.use(express.json());
appRouter.use(
  cors({
    origin: "*",
  })
);

dotenv.config();

const PORT = process.env.PORT || 5000;

appRouter.use("/", testRouter);
appRouter.use("/kwic", kwicRouter);

mongoose.connect(process.env.DBCONNECTIONSTRING ?? "", { dbName: "se6362-groupproject" }).then(() => console.log("Connected to MongoDB"));

appRouter.listen(PORT, () => {
    console.log("App listening at port " + PORT);
  }
);

export default appRouter;