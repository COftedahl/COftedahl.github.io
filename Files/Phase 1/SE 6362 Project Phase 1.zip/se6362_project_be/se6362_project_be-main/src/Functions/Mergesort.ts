/* 
 * function to implement mergesort of an array of strings
 * @param array: string array of the values to be sorted
 * @return: string array of the sorted values
 */
const mergesort = (array: string[]): string[] => {
  return mergesortHelper(array);
}

/* 
 * private helper function to recursivly mergesort array parts
 * @param array: string array of the values to be sorted
 * @return: string array of the sorted values
 */
const mergesortHelper = (array: string[]): string[] => {
  //base case: 1 item in the array
  if (array.length <= 1) {
    return array;
  }
  //recursive case: for any more than 1 item in array, call mergesort on the components split at the middle
  const indexOfLastElemInFirstArr: number = Math.floor((array.length - 1) / 2);
  const componentArr1: string[] = mergesortHelper(array.slice(0, indexOfLastElemInFirstArr + 1));
  const componentArr2: string[] = mergesortHelper(array.slice(indexOfLastElemInFirstArr + 1));

  return merge(componentArr1, componentArr2);
}
/* 
 * function to merge 2 sorted arrays of strings into a single sorted string array
 * @param arr1: sorted string array
 * @param arr2: sorted string array
 * @return: sorted string array with the components of arr1 and arr2 merged
 */
export const merge = (arr1: string[], arr2: string[]): string[] => {
  const mergedArr: string[] = [];

  let arr1Index: number = 0;
  let arr2Index: number = 0;

  while ((arr1Index < arr1.length) && (arr2Index < arr2.length)) {
    if (arr1[arr1Index] < arr2[arr2Index]) {
      mergedArr.push(arr1[arr1Index]);
      arr1Index += 1;
    }
    else {
      mergedArr.push(arr2[arr2Index]);
      arr2Index += 1;
    }
  }

  while (arr1Index < arr1.length) {
    mergedArr.push(arr1[arr1Index]);
    arr1Index += 1;
  }

  while (arr2Index < arr2.length) {
    mergedArr.push(arr2[arr2Index]);
    arr2Index += 1;
  }

  return mergedArr;
}

export default mergesort;