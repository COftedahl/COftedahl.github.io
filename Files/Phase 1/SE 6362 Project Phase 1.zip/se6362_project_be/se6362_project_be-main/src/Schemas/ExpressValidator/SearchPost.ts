const SearchPost = {
  searchString: {
    isString: true, 
  }
}

export default SearchPost;