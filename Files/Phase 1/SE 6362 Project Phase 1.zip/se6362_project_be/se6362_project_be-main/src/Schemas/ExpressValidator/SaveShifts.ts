const SaveShifts = {
  unshiftedString: {
    isString: true, 
  }, 
  urls: {
    isArray: true, 
  }
};

export default SaveShifts;