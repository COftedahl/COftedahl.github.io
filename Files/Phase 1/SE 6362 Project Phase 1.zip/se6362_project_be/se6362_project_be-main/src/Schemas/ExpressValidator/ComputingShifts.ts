const ComputingShifts = {
  unshiftedString: {
    isString: true, 
  }, 
};

export default ComputingShifts;