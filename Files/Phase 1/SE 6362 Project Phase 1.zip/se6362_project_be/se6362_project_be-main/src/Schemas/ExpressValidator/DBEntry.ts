// import { checkSchema } from "express-validator";

const DBEntry = {
  searchString: {
    isString: true, 
    exists: true,
    notEmpty: true, 
    trim: true, 
    escape: true, 
  }, 
  relatedURLs: {
    isArray: true, 
    exists: true, 
    escape: true, 
    trim: true, 
  },
};

export default DBEntry;