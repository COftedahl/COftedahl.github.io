import mongoose from "mongoose";

const DBEntrySchema = new mongoose.Schema(
  {
    searchString: {
      type: String, 
      require: true, 
    }, 
    relatedURLs: {
      type: [String], 
      require: true, 
    }
  }
)

DBEntrySchema.index({searchString: 1})

const DBEntry = mongoose.model("DBEntry", DBEntrySchema, "websites");

export default DBEntry;