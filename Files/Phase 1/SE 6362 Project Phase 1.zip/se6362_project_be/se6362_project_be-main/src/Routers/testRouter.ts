import express from 'express';

const testRouter = express.Router();

//function to show connection to the server
testRouter.get("", async (req, res) => {
  res.json("You found the SE6362 Project Back End Server - Test Router");
})

export default testRouter;