export const enum KWIC_CLASS {
  INPUT_HANDLER, 
  LINE_STORAGE, 
  CIRCULAR_SHIFTER, 
  NOISE_ELIMINATOR, 
  ALPHABETIZER, 
  OUTPUT_HANDLER, 
}

export const enum KWIC_PROCESSING_STAGE {
  UNSHIFTED_LINE, 
  SHIFTED_LINES, 
  ALPHABETIZED_LINES, 
}

interface IKWICClassProcessingMessage {
  sourceModule: KWIC_CLASS, 
  processingStage: KWIC_PROCESSING_STAGE, 
  data: string, 
}

export default IKWICClassProcessingMessage;