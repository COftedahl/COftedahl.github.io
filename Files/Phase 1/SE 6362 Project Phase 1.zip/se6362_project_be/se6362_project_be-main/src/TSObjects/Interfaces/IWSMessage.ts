export interface IWSWindowContent {
    content: string, 
    colorIndex: number, 
}

interface IWSMessage {
  windowIndex: 0 | 1 | 2, 
  newWindowContent: IWSWindowContent[], 
}

export default IWSMessage;