interface IURLTitlePair {
  title: string, 
  url: string, 
}

export default IURLTitlePair;