interface IDBEntry {
  searchString: string, 
  relatedURLs: string[], 
}

export default IDBEntry;