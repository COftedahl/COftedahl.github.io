import DBInterface from "./DBInterface";

class Search {
  private dbInterface: DBInterface;
  
  /* 
   * function to retrieve a set of results from the database for a given input search string, to send the results to the front end
   * @param searchString: string for the search phrase input
   * @return: string array of results fetched from the database
   */
  public getSearchResults: (searchString: string) => Promise<string[]>

  constructor() {
    this.dbInterface = new DBInterface();

    this.getSearchResults = async (searchString: string) => {
      return await this.dbInterface.getSearchPhraseEntries(searchString);
    }
  }
}

export default Search;