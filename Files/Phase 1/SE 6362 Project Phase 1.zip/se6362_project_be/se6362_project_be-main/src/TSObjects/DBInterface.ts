import DBEntry from "../Schemas/Mongoose/DBEntry";
import IDBEntry from "./Interfaces/IDBEntry";
import {default as DBEntryValidatorSchema } from "../Schemas/ExpressValidator/DBEntry";
import { checkSchema, matchedData, validationResult } from "express-validator";

class DBInterface {
  /* 
   * function to store a set of circularly shifted lines into the database
   * @param entries: the lines to be shifted
   */
  public storeCircularShiftedLines: (entries: IDBEntry[]) => Promise<void>;

  /* 
   * function to retrieve entries from the database for a search string input
   * @param searchString: the entry which shall be searched for in the database
   * @return: string array of results from the database
   */
  public getSearchPhraseEntries: (searchString: string) => Promise<string[]>;

  /* 
   * function to retrieve autocomplete options stored in the db
   * @return: string array of autocomplete options found in the db
   */
  public getPossibleSearchPhrases: () => Promise<string[]>;

  /* 
   * function to remove entries from the db
   * @param elemRemoving: either a string representing the search string for which all corresponding URLs should be removed, or
   *      an IDBEntry object which indicates which URLs should be removed from the given search string
   */
  public removeDBEntry: (elemRemoving: string | IDBEntry) => Promise<void>;

  constructor() {
    this.storeCircularShiftedLines = async (entries: IDBEntry[]) => {
      const sanitizedEntries: IDBEntry[] = [];

      //map through entries trying to store, and sanitize each
      for (let entry of entries) {
        const reqObj: {body: IDBEntry} = {body: entry};
        await checkSchema(DBEntryValidatorSchema).run(reqObj);
        const error = validationResult(reqObj);

        if (!error.isEmpty()) {
          console.log(error.mapped());
          console.log("Error in DBInterface_storeCircularShiftedLines entries argument");
          return;
        }

        const sanitizedEntry: IDBEntry = matchedData(reqObj); 
        sanitizedEntries.push(sanitizedEntry);
      }

      //store the sanitized entries in the db
      if (sanitizedEntries.length > 0) {
        for (let sanitizedEntry of sanitizedEntries) {
          const oldURLs: string[] = await this.getSearchPhraseEntries(sanitizedEntry.searchString);
          if (oldURLs.length > 0) {
            //modify existing record
            // await DBEntry.updateOne({searchString: sanitizedEntry.searchString}, {searchString: sanitizedEntry.searchString, relatedURLs: [...oldURLs, ...sanitizedEntry.relatedURLs]})
            await DBEntry.updateOne({searchString: sanitizedEntry.searchString}, {searchString: sanitizedEntry.searchString, relatedURLs: sanitizedEntry.relatedURLs})
          }
          else {
            //create new record
            await DBEntry.create(sanitizedEntry);
          }
        }
        
      }
    }

    this.getSearchPhraseEntries = async (searchString: string) => {
      const entry: IDBEntry | null = await DBEntry.findOne({searchString: searchString});
      return (entry !== null ? entry.relatedURLs : []);
    }

    this.getPossibleSearchPhrases = async () => {
      return (await DBEntry.find({},{searchString: 1})).map((document: any) => document.searchString)
    }

    this.removeDBEntry = async (elemRemoving: string | IDBEntry) => {
      if ((!(elemRemoving as IDBEntry).relatedURLs) || ((elemRemoving as IDBEntry).relatedURLs.length <= 0)) {
        //elemRemoving is a string
        await DBEntry.deleteOne({searchString: elemRemoving});
      }
      else {
        //elemRemoving is an IDBEntry
        const elemRemovingIDBEntry: IDBEntry = elemRemoving as IDBEntry;
        //first, get the current list of URLs
        const currURLs: string[] = await this.getSearchPhraseEntries(elemRemovingIDBEntry.searchString);
        //then, update the list of URLs by removing the URLs passed in elemRemoving
        const newURLs: string[] = currURLs.filter((oldURL: string) => !elemRemovingIDBEntry.relatedURLs.includes(oldURL));
        if (newURLs.length > 0) {
          //if there are still urls left, then update the db
          await DBEntry.updateOne({searchString: elemRemovingIDBEntry.searchString}, {searchString: elemRemovingIDBEntry.searchString, relatedURLs: newURLs});
        }
        else {
          //no urls left, so delete the db entry
          await DBEntry.deleteOne({searchString: elemRemovingIDBEntry.searchString});
        }
      }
      return;
    }
  }
}

export default DBInterface;