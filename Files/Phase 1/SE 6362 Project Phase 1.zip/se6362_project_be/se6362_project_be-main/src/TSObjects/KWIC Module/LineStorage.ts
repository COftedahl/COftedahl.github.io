import KWICModuleBaseClass from "./KWICModuleBaseClass";

class LineStorage extends KWICModuleBaseClass {

  constructor() {
    super();
  }

}

export default LineStorage;