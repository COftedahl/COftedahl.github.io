import DataMedium from "./DataMedium";

class OutputMedium extends DataMedium{}

export default OutputMedium;