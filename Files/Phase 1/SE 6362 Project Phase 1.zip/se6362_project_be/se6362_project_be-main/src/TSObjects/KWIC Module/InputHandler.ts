import { lineDelimiter, wordDelimiter } from "../constants";
import InputMedium from "./InputMedium";
import KWICModuleBaseClass from "./KWICModuleBaseClass";

class InputHandler {
  private lineStorage?: KWICModuleBaseClass;
  public getInputLines: () => Promise<void>;
  public storeInputLines: (inputLines: string) => Promise<void>;

  constructor(lineStorage?: KWICModuleBaseClass) {
    this.lineStorage = lineStorage;

    this.getInputLines = async () => {
      const data: string = await InputMedium.getSingleton().read();
      await this.storeInputLines(data);
    }

    this.storeInputLines = async (inputLines: string) => {
      if (this.lineStorage) {
        const lines: string[] = inputLines.split(lineDelimiter);
        let lineNum: number = 0;
        let wordNum: number = 0;
        let charNum: number = 0;
        for (let line of lines) {
          wordNum = 0;
          const words: string[] = line.split(wordDelimiter);
          for (let word of words) {
            charNum = 0;
            for (let char of word) {
              await this.lineStorage.setChar(lineNum, wordNum, charNum, char);
              charNum += 1;
            }
            wordNum += 1
          }
          lineNum += 1;
        }
      }
    }
  }
}

export default InputHandler;