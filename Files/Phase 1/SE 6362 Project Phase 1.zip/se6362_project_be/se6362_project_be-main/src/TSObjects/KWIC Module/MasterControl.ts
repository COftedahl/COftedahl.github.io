import { lineDelimiter } from "../constants";
import IKWICClassProcessingMessage from "../Interfaces/IKWICClassProcessingMessage";
import Alphabetizer from "./Alphabetizer";
import CircularShifter from "./CircularShifter";
import InputHandler from "./InputHandler";
import InputMedium from "./InputMedium";
import LineStorage from "./LineStorage";
import Listener from "./Listener";
import NoiseEliminator from "./NoiseEliminator";
import OutputHandler from "./OutputHandler";
import OutputMedium from "./OutputMedium";

class MasterControl {
  private inputMedium: InputMedium;
  private inputHandler: InputHandler;
  private lineStorage: LineStorage;
  private circularShifter: CircularShifter;
  private noiseEliminator: NoiseEliminator;
  private alphabetizer: Alphabetizer;
  private outputHandler: OutputHandler;
  private outputMedium: OutputMedium;
  private listener: Listener;
  public getCircularShiftedLines: (unshiftedLines: string[]) => Promise<string[]>;
  public attachListener: (callback: (message: IKWICClassProcessingMessage) => Promise<void>) => Promise<void>;
  public removeListener: () => Promise<void>;

  constructor() {
    this.inputMedium = InputMedium.getSingleton();
    this.lineStorage = new LineStorage();
    this.inputHandler = new InputHandler(this.lineStorage);
    this.circularShifter = new CircularShifter(this.lineStorage);
    this.noiseEliminator = new NoiseEliminator(this.circularShifter);
    this.alphabetizer = new Alphabetizer(this.noiseEliminator);
    this.outputHandler = new OutputHandler(this.alphabetizer);
    this.outputMedium = OutputMedium.getSingleton();
    this.listener = new Listener();

    this.getCircularShiftedLines = async (unshiftedLines: string[]) => {
      // console.log("Master control called with lines: ", unshiftedLines);
      await this.inputMedium.write(unshiftedLines.join(lineDelimiter));
      await this.inputHandler.getInputLines();
      await this.circularShifter.retrieveLineStorageLines();
      // console.log("LS: ", await this.lineStorage.getLines());
      //loop while there are lines in lineStorage to process
      while (await this.circularShifter.word(0) > 0) {
      // console.log("CS: ", await this.circularShifter.getLines());
      // if (await this.circularShifter.word(0) > 0) {
        await this.noiseEliminator.retrieveCircularShiftLines();
        await this.alphabetizer.retrieveNoiselessLines();
        // console.log("NE: ", await this.noiseEliminator.getLines());
        
        await this.circularShifter.retrieveLineStorageLines();
        // console.log("AB: ", await this.alphabetizer.getLines());
      }
      await this.outputHandler.getAlphabetizedLines();

      //reset internal state of objects
      this.circularShifter.resetLines();
      this.noiseEliminator.resetLines();
      this.alphabetizer.resetLines();

      return (await this.outputMedium.read()).split(lineDelimiter);
    }

    this.attachListener = async (callback: (message: IKWICClassProcessingMessage) => Promise<void>) => {
      await this.listener.attachListener(callback);
    }

    this.removeListener = async () => {
      await this.listener.removeListener();
    }
  }
}

export default MasterControl;