import { lineDelimiter, noiseWords, wordDelimiter } from "../constants";
import KWICModuleBaseClass from "./KWICModuleBaseClass";

class NoiseEliminator extends KWICModuleBaseClass {
  private prevObject?: KWICModuleBaseClass;
  public retrieveCircularShiftLines: () => Promise<void>;
  private removeNoisyLines: (noisyLines: string[]) => Promise<string[]>;
  private static noiseWords: Set<string> = new Set<string>(noiseWords.map((word: string) => word.toLowerCase()));

  constructor(prevObject?: KWICModuleBaseClass) {
    super();

    this.prevObject = prevObject;

    this.retrieveCircularShiftLines = async () => {
      if (this.prevObject) {
        let words: string[] = [];
        const lines: string[] = [];
        let numWords: number = await this.prevObject.word(0);
        
        while (numWords > 0) {
          words = [];
          let charIndex: number = 0;
          let char: string = '';
          for (let i = 0; i < numWords; i += 1) {
            charIndex = 0;
            words.push("");
            char = await this.prevObject.char(0, i, charIndex);
            while (char !== '') {
              words[i] += char;
              charIndex += 1;
              char = await this.prevObject.char(0, i, charIndex);
            }
          }
          const newLine: string = words.join(wordDelimiter);
          lines.push(newLine);
          await this.prevObject.removeFirstLine();
          numWords = await this.prevObject.word(0);
        }

        await this.removeNoisyLines(lines);
      }
    }

    this.removeNoisyLines = async (noisyLines: string[]) => {
      const noiselessLines: string[] = [];

      //remove noisy lines
      for (let line of noisyLines) {
        const indexOfFirstWordDelimiter: number = line.indexOf(wordDelimiter);
        const wordChecking: string = line.substring(0, (indexOfFirstWordDelimiter < 0 ? line.length : indexOfFirstWordDelimiter));
        if (!NoiseEliminator.noiseWords.has(wordChecking.toLowerCase())) {
          noiselessLines.push(line);
        }
      }

      await this.persistLines(noiselessLines);

      return noiselessLines;
    }
  }
}

export default NoiseEliminator;