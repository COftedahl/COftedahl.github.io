import mongoose from "mongoose";
import DBInterface from "../../TSObjects/DBInterface";
import dotenv from "dotenv";

let connection: mongoose.Mongoose;
let dbInterface: DBInterface = new DBInterface();

beforeEach(() => {

})

beforeAll(async () => {
  dotenv.config();
  connection = await mongoose.connect(process.env.DBCONNECTIONSTRING ?? "", { dbName: "se6362-groupproject" })
})

test("retrieve one url", async () => {
  expect(await dbInterface.getSearchPhraseEntries("team website")).toContain("https://coftedahl.github.io/");
})

test("check validation output for storeCircularShifts", async () => {
  const searchString: string = "hello world";
  const relatedURL: string = "test string";

  await dbInterface.storeCircularShiftedLines([
    {
      searchString: searchString,
      relatedURLs: [relatedURL]
    }
  ])
  expect(await dbInterface.getSearchPhraseEntries(searchString)).toStrictEqual([relatedURL]);

  await dbInterface.removeDBEntry(searchString);
})

test("check validation output for invalid storeCircularShifts", async () => {
  const searchString: string = "a";
  const relatedURL: string = "";

  await dbInterface.storeCircularShiftedLines([
    {
      searchString: searchString,
      relatedURLs: [relatedURL]
    }
  ])
  expect(await dbInterface.getSearchPhraseEntries(searchString)).toStrictEqual([relatedURL]);

  await dbInterface.removeDBEntry(searchString);
})

test("check db delete mechanism - whole entry", async () => {
  const searchString: string = "b";
  const relatedURL: string = "";

  await dbInterface.storeCircularShiftedLines([
    {
      searchString: searchString,
      relatedURLs: [relatedURL]
    }
  ])
  await dbInterface.removeDBEntry(searchString);
  expect(await dbInterface.getSearchPhraseEntries(searchString)).toStrictEqual([]);
})

test("check db delete mechanism - partial entry", async () => {
  const searchString: string = "c";
  const relatedURL1: string = "d";
  const relatedURL2: string = "e";

  await dbInterface.storeCircularShiftedLines([
    {
      searchString: searchString,
      relatedURLs: [relatedURL1, relatedURL2]
    }
  ])
  await dbInterface.removeDBEntry({searchString: searchString, relatedURLs: [relatedURL1]});
  expect(await dbInterface.getSearchPhraseEntries(searchString)).toStrictEqual([relatedURL2]);
  await dbInterface.removeDBEntry(searchString);
})

test("check getPossibleSearchPhrases", async () => {
  const searchString: string = "team website";
  const result: string[] = await dbInterface.getPossibleSearchPhrases();
  expect(result).toContain(searchString);
})

afterAll(async () => {
  await connection.disconnect();
})