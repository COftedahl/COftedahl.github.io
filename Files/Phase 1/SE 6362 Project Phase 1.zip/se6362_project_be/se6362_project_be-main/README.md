To build typescript into executable javascript, run "npm run build"

To run the server once built into javascript, run "npm start"

To run the tests, run "npm test"