import mongoose from "mongoose";
import DBInterface from "../../TSObjects/DBInterface";
import dotenv from "dotenv";
import { IDBUrlEntry } from "../../TSObjects/Interfaces/IDBEntry";

let connection: mongoose.Mongoose;
let dbInterface: DBInterface = new DBInterface();

const convertURLStringToIDBUrlEntry = (url: string): IDBUrlEntry => {
  return {
    url: url, 
    paymentValue: 1.0, 
    accessFrequency: 1.0, 
    dateAdded: "", 
  }
}

beforeEach(() => {

})

beforeAll(async () => {
  dotenv.config();
  connection = await mongoose.connect(process.env.DBCONNECTIONSTRING ?? "", { dbName: "se6362-groupproject" })
})

test("retrieve one url", async () => {
  expect((await dbInterface.getSearchPhraseEntries("team website")).map((entry: IDBUrlEntry) => entry.url)).toContain("https://coftedahl.github.io/");
})

test("check validation output for storeCircularShifts", async () => {
  const searchString: string = "hello world";
  const relatedURL: string = "test string";
  const requestObject = {
    searchString: searchString,
    relatedURLs: [
      convertURLStringToIDBUrlEntry(relatedURL)
    ], 
  }

  await dbInterface.storeCircularShiftedLines([requestObject])
  expect((await dbInterface.getSearchPhraseEntries(searchString)).map((entry: IDBUrlEntry) => entry.url)).toStrictEqual([relatedURL]);

  await dbInterface.removeDBEntry(searchString);
})

test("check validation output for invalid storeCircularShifts", async () => {
  const searchString: string = "a";
  const relatedURL: string = "";

  await dbInterface.storeCircularShiftedLines([
    {
      searchString: searchString,
      relatedURLs: [convertURLStringToIDBUrlEntry(relatedURL)]
    }
  ])
  expect((await dbInterface.getSearchPhraseEntries(searchString)).map((entry: IDBUrlEntry) => entry.url)).toStrictEqual([relatedURL]);

  await dbInterface.removeDBEntry(searchString);
})

test("check db delete mechanism - whole entry", async () => {
  const searchString: string = "b";
  const relatedURL: string = "";

  await dbInterface.storeCircularShiftedLines([
    {
      searchString: searchString,
      relatedURLs: [convertURLStringToIDBUrlEntry(relatedURL)]
    }
  ])
  await dbInterface.removeDBEntry(searchString);
  expect(await dbInterface.getSearchPhraseEntries(searchString)).toStrictEqual([]);
})

test("check db delete mechanism - partial entry", async () => {
  const searchString: string = "c";
  const relatedURL1: string = "d";
  const relatedURL2: string = "e";

  await dbInterface.storeCircularShiftedLines([
    {
      searchString: searchString,
      relatedURLs: [convertURLStringToIDBUrlEntry(relatedURL1), convertURLStringToIDBUrlEntry(relatedURL2)]
    }
  ])
  await dbInterface.removeDBEntry({searchString: searchString, relatedURLs: [convertURLStringToIDBUrlEntry(relatedURL1)]});
  expect((await dbInterface.getSearchPhraseEntries(searchString)).map((entry: IDBUrlEntry) => entry.url)).toStrictEqual([relatedURL2]);
  await dbInterface.removeDBEntry(searchString);
})

test("check getPossibleSearchPhrases", async () => {
  const searchString: string = "team website";
  const result: string[] = await dbInterface.getPossibleSearchPhrases();
  expect(result).toContain(searchString);
})

test ("check incrementAccesses", async () => {
  const title: string = "f";
  const url: string = "g";
  await dbInterface.storeCircularShiftedLines([{
    searchString: title,
    relatedURLs: [{
      url: url, 
      paymentValue: 2, 
      accessFrequency: 3, 
      dateAdded: "", 
    }]
  }]);

  await dbInterface.incrementAccesses({
    title: title,
    url: {
      url: url, 
      paymentValue: 0, 
      accessFrequency: 0, 
      dateAdded: "", 
    }, 
  })
  const result: any[] = await dbInterface.getSearchPhraseEntries(title);
  const expected: IDBUrlEntry = {
    url: url, 
    paymentValue: 2, 
    accessFrequency: 4, 
    dateAdded: "", 
  };
  expect({url: result[0].url, paymentValue: result[0].paymentValue, accessFrequency: result[0].accessFrequency, dateAdded: result[0].dateAdded}).toStrictEqual(expected);
  await dbInterface.removeDBEntry(title);
})

afterAll(async () => {
  await connection.disconnect();
})