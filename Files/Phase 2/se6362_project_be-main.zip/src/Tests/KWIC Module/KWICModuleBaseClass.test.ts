import KWICModuleBaseClass from "../../TSObjects/KWIC Module/KWICModuleBaseClass";

let baseClass: KWICModuleBaseClass = new KWICModuleBaseClass();

beforeEach(() => {
  baseClass.resetLines();
});

test('setChar creating line', async () => {
  await baseClass.setChar(0,0,0,'a');
  expect(await baseClass.char(0,0,0)).toBe('a');
});

test('setChar adding character', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,0,1,'b');
  expect(await baseClass.char(0,0,0)).toBe('a');
  expect(await baseClass.char(0,0,1)).toBe('b');
});

test('setChar overwriting character', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,0,0,'b');
  expect(await baseClass.char(0,0,0)).toBe('b');
});

test('setChar creating word', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,1,0,'b');
  expect(await baseClass.char(0,0,0)).toBe('a');
  expect(await baseClass.char(0,1,0)).toBe('b');
});

test('setChar with invalid line value 0', async () => {
  await baseClass.setChar(1,0,0,'a');
  expect(await baseClass.char(1,0,0)).toBe('');
})

test('setChar with invalid line value 1', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(2,0,0,'b');
  expect(await baseClass.char(2,0,0)).toBe('');
})

test('setChar with invalid word value 0', async () => {
  await baseClass.setChar(0,1,0,'a');
  expect(await baseClass.char(0,1,0)).toBe('');
})

test('setChar with invalid line value 1', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,2,0,'b');
  expect(await baseClass.char(0,2,0)).toBe('');
})

test('setChar with invalid character value 0', async () => {
  await baseClass.setChar(0,0,1,'a');
  expect(await baseClass.char(0,0,1)).toBe('');
})

test('setChar with invalid character value 1', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,0,2,'b');
  expect(await baseClass.char(0,0,2)).toBe('');
})

test('setChar with invalid character value 2', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,1,2,'b');
  expect(await baseClass.char(0,0,2)).toBe('');
})

test('word with valid line value 0', async () => {
  await baseClass.setChar(0,0,0,'a');
  expect(await baseClass.word(0)).toBe(1);
})

test('word with valid line value 1', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,0,1,'b');
  expect(await baseClass.word(0)).toBe(1);
})

test('word with valid line value 2', async () => {
  await baseClass.setChar(0,0,0,'a');
  await baseClass.setChar(0,1,0,'b');
  expect(await baseClass.word(0)).toBe(2);
})

test('word with invalid line value 0', async () => {
  expect(await baseClass.word(0)).toBe(-1);
})

afterEach(() => {

});