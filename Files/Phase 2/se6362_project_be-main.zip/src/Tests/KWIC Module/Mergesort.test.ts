import mergesort from "../../Functions/Mergesort";

test("10 lines mergesort", () => {
  const testString: string = "abc def ghi\naab aba abb\naaa bbb ccc\nbaa bab bba\nace car cab\nash arc ape\naid ail aim\narm all alt\nbar bet bat\nban bam ball\ncam car cash";
  const sortedResult: string[] = mergesort(testString.split("\n"));
  expect(sortedResult.length).toBe(11);
})

// test("10 lines, 3 strings each mergesort", async () => {
//   const shifter: MasterControl = new MasterControl();
//   const testString: string = "abc def ghi\naab aba abb\naaa bbb ccc\nbaa bab bba\nace car cab\nash arc ape\naid ail aim\narm all alt\nbar bet bat\nban bam ball\ncam car cash";
//   const shiftedStrings: string[] = await shifter.getCircularShiftedLines(testString.split("\n"));
//   console.log(shiftedStrings);
//   expect(1).toBe(0)
// })