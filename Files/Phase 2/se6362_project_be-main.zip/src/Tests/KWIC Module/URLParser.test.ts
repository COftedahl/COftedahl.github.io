import URLParser from "../../TSObjects/URLParser";

const urlParser: URLParser = new URLParser;

beforeEach(() => {

})

test('testURLParser Valid 1', async () => {
  expect(urlParser.isValidURL("a.com")).toBe(true);
});

test('testURLParser Valid 2', async () => {
  expect(urlParser.isValidURL("https://hellothere.com")).toBe(true);
});

test('testURLParser Valid 3', async () => {
  expect(urlParser.isValidURL("http://hellothere.com")).toBe(true);
});

test('testURLParser Valid 4', async () => {
  expect(urlParser.isValidURL("hellothere.com/")).toBe(true);
});

test('testURLParser Valid 5', async () => {
  expect(urlParser.isValidURL("hellothere.com/abc")).toBe(true);
});

test('testURLParser Valid 6', async () => {
  expect(urlParser.isValidURL("hellothere.com/abc/def/")).toBe(true);
});

test('testURLParser Valid 7', async () => {
  expect(urlParser.isValidURL("hellothere.com/abc?")).toBe(true);
});

test('testURLParser Valid 8', async () => {
  expect(urlParser.isValidURL("hellothere.com/abc?key=val&%20%50890324801adfhv")).toBe(true);
});

test('testURLParser Valid 9', async () => {
  expect(urlParser.isValidURL("https://secret.files.static.hellothere.com/abc")).toBe(true);
});

test('testURLParser Valid 10', async () => {
  expect(urlParser.isValidURL("https://se3cre2t.fil2es.sta4tic.hello2th4ere2.com/abc")).toBe(true);
});

test('testURLParser Invalid 1', async () => {
  expect(urlParser.isValidURL("httpss://hellothere.com")).toBe(false);
});

test('testURLParser Invalid 2', async () => {
  expect(urlParser.isValidURL("https:/hellothere.com")).toBe(false);
});

test('testURLParser Invalid 3', async () => {
  expect(urlParser.isValidURL("h1.aa")).toBe(false);
});

test('testURLParser Invalid 4', async () => {
  expect(urlParser.isValidURL("https://1oclock.com")).toBe(false);
});

test('testURLParser Invalid 5', async () => {
  expect(urlParser.isValidURL("https://1.com")).toBe(false);
});

test('testURLParser Invalid 6', async () => {
  expect(urlParser.isValidURL("hellothere.com/()")).toBe(false);
});

test('testURLParser Invalid 7', async () => {
  expect(urlParser.isValidURL("/hellothere.com")).toBe(false);
});

test('testURLParser Invalid 8', async () => {
  expect(urlParser.isValidURL("https://a.b.c.d.hellothere.com")).toBe(false);
});

test('testURLParser Invalid 9', async () => {
  expect(urlParser.isValidURL("hellothere.com1")).toBe(false);
});

test('testURLParser Invalid 10', async () => {
  expect(urlParser.isValidURL("hellothere.co2m")).toBe(false);
});

afterEach(() => {

})