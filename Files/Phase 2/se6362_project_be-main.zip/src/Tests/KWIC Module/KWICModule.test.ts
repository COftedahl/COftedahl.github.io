import { lineDelimiter } from "../../TSObjects/constants";
import MasterControl from "../../TSObjects/KWIC Module/MasterControl"

let masterControl: MasterControl;

beforeEach(() => {
  masterControl = new MasterControl();
})

test("module integration 1 line 1", async () => {
  const inputLines: string[] = ["Beast"];
  const expectedLines: string[] = [
    "Beast", 
  ]
  
  expect(await masterControl.getCircularShiftedLines(inputLines)).toStrictEqual(expectedLines);
})

test("module integration 1 line 2", async () => {
  const inputLines: string[] = ["Beauty and the Beast"];
  const expectedLines: string[] = [
    "Beast Beauty and the", 
    "Beauty and the Beast", 
  ]
  
  expect(await masterControl.getCircularShiftedLines(inputLines)).toStrictEqual(expectedLines);
})

test("module integration 1 line 3", async () => {
  const inputLines: string[] = ["Beauty and Beast"];
  const expectedLines: string[] = [
    "Beast Beauty and", 
    "Beauty and Beast", 
  ]
  
  expect(await masterControl.getCircularShiftedLines(inputLines)).toStrictEqual(expectedLines);
})

test("module integration 1 line 4", async () => {
  const inputLines: string[] = ["ab"];
  const expectedLines: string[] = [
    "ab", 
  ]
  
  expect(await masterControl.getCircularShiftedLines(inputLines)).toStrictEqual(expectedLines);
})

test("module integration 2 lines 1", async () => {
  const inputLines: string[] = ["Beauty and the Beast", "Hello to the World"];
  const expectedLines: string[] = [
    "Beast Beauty and the", 
    "Beauty and the Beast", 
    "Hello to the World", 
    "World Hello to the",
  ]
  
  expect(await masterControl.getCircularShiftedLines(inputLines)).toStrictEqual(expectedLines);
})

test("module integration 3 lines 1", async () => {
  const inputLines: string[] = ["Beauty and the Beast", "Hello to the World", "A Very Long Line Which Shall Make Many Shifts"];
  const expectedLines: string[] = [
    "Beast Beauty and the", 
    "Beauty and the Beast", 
    "Hello to the World", 
    "Line Which Shall Make Many Shifts A Very Long", 
    "Long Line Which Shall Make Many Shifts A Very", 
    "Make Many Shifts A Very Long Line Which Shall", 
    "Many Shifts A Very Long Line Which Shall Make", 
    "Shall Make Many Shifts A Very Long Line Which", 
    "Shifts A Very Long Line Which Shall Make Many", 
    "Very Long Line Which Shall Make Many Shifts A", 
    "World Hello to the",
  ]
  
  expect(await masterControl.getCircularShiftedLines(inputLines)).toStrictEqual(expectedLines);
})