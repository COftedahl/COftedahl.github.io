import DataMedium from "../../TSObjects/KWIC Module/DataMedium";

// let dataMedium: DataMedium = DataMedium.getSingleton();
let dataMedium: DataMedium = new DataMedium();

beforeEach(() => {
  dataMedium.read(); //clears write buffer
})

test("read blank", async () => {
  expect(await dataMedium.read()).toBe("");
})

test("write and read", async () => {
  const sampleString: string = "Some text";
  dataMedium.write(sampleString);
  expect(await dataMedium.read()).toBe(sampleString);
})

test("write and read async", async () => {
  const sampleString1: string = "Some text";
  const sampleString2: string = "Other text";
  dataMedium.write(sampleString1);
  dataMedium.write(sampleString2);
  expect(await dataMedium.read()).toBe(sampleString1 + sampleString2);
})