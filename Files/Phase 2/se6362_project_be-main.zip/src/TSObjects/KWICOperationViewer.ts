import { lineDelimiter, WSS_PORT } from "./constants";
import IKWICClassProcessingMessage, { KWIC_PROCESSING_STAGE } from "./Interfaces/IKWICClassProcessingMessage";
import IWSMessage, { IWSWindowContent } from "./Interfaces/IWSMessage";
import MasterControl from "./KWIC Module/MasterControl";
import { WebSocketServer, WebSocket } from 'ws';

interface ConnectionStore {
  socket: WebSocket, 
  shiftedLineCollection: {
    colorIndex: number, 
    shiftedLines: string[]
  }[], 
  currentColorIndex: number
}

class KWICOperationViewer {
  private static connectionList: Set<ConnectionStore> = new Set();
  private static wss: WebSocketServer = new WebSocketServer({port: WSS_PORT})
  .on(
    "connection", (ws: WebSocket) => {
      //persist the connection so messages can be sent to the client for real-time updates
      this.connectionList.add({socket: ws, shiftedLineCollection: [], currentColorIndex: 0});

      //event occurs when a client sends a message to the server - shouldn't occur, so we don't really need to process it
      ws.on("message", (message: any) => {

      })

      //when client disconnects, remove the persisted data from the connectionList
      ws.on("close", () => {
        const deletingEntry: ConnectionStore | undefined = Array.from(this.connectionList.keys()).find((entry: ConnectionStore) => entry.socket === ws);
        if (deletingEntry) {
          this.connectionList.delete(deletingEntry);
        }
      })
    }
  );

  /* 
   * function to check whether a given line is in the connection store or not
   * @param line: string indicating the line we want to determine the presence of in the connectionList.shiftedLineCollection.shiftedLines variables
   * @return: boolean value; true if any entry in connectionList has an entry in shiftedLines in shiftedLineCollection matching the line; else false
   */
  private static isLineInConnectionList = (line: string): boolean => {
    return (KWICOperationViewer.getLineColorInConnectionList(line) >= 0)
  };

  /* 
   * function to get the color of a line sent by the connection
   * @param line: string indicating the line we want to determine the color of in the connectionList.shiftedLineCollection.shiftedLines variables
   * @return: integer representing the stored colorIndex value for the line, or -1 if the line is not found
   */
  private static getLineColorInConnectionList = (line: string): number => {
    for (let connection of KWICOperationViewer.connectionList) {
      for (let shiftedLineSet of connection.shiftedLineCollection) {
        for (let shiftedLine of shiftedLineSet.shiftedLines) {
          if (shiftedLine === line) {
            return shiftedLineSet.colorIndex;
          }
        }
      }
    }
    return -1;
  }

  /* 
   * function to get the color of a line sent by the connection
   * @param line: string indicating the line we want to determine the color of in the connectionList.shiftedLineCollection.shiftedLines variables
   * @return: integer representing the stored colorIndex value for the line, or -1 if the line is not found
   */
  private static getLineColorInConnectionStore = (line: string, store: ConnectionStore): number => {
    for (let shiftedLineSet of store.shiftedLineCollection) {
      for (let shiftedLine of shiftedLineSet.shiftedLines) {
        if (shiftedLine === line) {
          return shiftedLineSet.colorIndex;
        }
      }
    }
    return -1;
  }

  /* 
   * function to get the socket from the connectionList which has stored a line sent previously
   * @param line: string indicating the line we want to match having been sent previously in the connectionList.shiftedLineCollection.shiftedLines variables
   * @return: connectionStore item for the connection that has sent it before, or null if no associated connection found
   */
  private static getConnectionStoreOfString = (line: string): ConnectionStore | null => {
    for (let connection of KWICOperationViewer.connectionList) {
      for (let shiftedLineSet of connection.shiftedLineCollection) {
        for (let shiftedLine of shiftedLineSet.shiftedLines) {
          if (shiftedLine === line) {
            return connection;
          }
        }
      }
    }
    return null;
  }

  /* 
   * function to get the connectionStore from the connectionList which contains a particular socket
   * @param socket: WebSocket
   * @return: connectionStore item containing the input socket
   */
  private static getConnectionStoreOfSocket = (socket: WebSocket): ConnectionStore | null => {
    for (let connection of KWICOperationViewer.connectionList) {
      if (connection.socket === socket) {
        return connection;
      }
    }
    return null;
  }
  
  private masterControl: MasterControl;
  /* 
   * function to perform the circular shift computation while enabling the viewing in real-time
   * @return: string array of the circular shift results
   */
  public viewCircularShiftsRealTime: (unshiftedLines: string[]) => Promise<string[]>;

  /* 
   * function to set the listener on the KWIC Module to allow real-time viewing
   */
  public setListener: () => void;

  /* 
   * function to remove the listener from the KWIC Module to eliminate unnecessary overhead while not using the real-time viewing
   */
  public removeListener: () => void;  

  constructor() {
    this.masterControl = new MasterControl();

    this.viewCircularShiftsRealTime = async (unshiftedLines: string[]) => {
      this.setListener();
      
      const shiftedLines: string[] = await this.masterControl.getCircularShiftedLines(unshiftedLines);
      // this.removeListener();//don't want to remove listener here, because the 
        //message are sent over a longer period than when the messages are processed
      return shiftedLines;
    }

    this.setListener = () => {
      this.masterControl.attachListener(async (message: IKWICClassProcessingMessage) => {
        switch (message.processingStage) {
          case KWIC_PROCESSING_STAGE.UNSHIFTED_LINE: {
            //update the unshifted line being processed

            //first, get the connection store that has sent the string
            const connectionStore: ConnectionStore | null = KWICOperationViewer.getConnectionStoreOfString(message.data);
            let colorIndex: number = 0;
            //if the connection was found, then assign the color of the line from that
            if (connectionStore !== null) {
              colorIndex = KWICOperationViewer.getLineColorInConnectionStore(message.data, connectionStore);
              //check if this line has been sent before
              if (colorIndex === -1) {
                //line has not been sent before - assign it a new color
                connectionStore.currentColorIndex += 1;
                connectionStore.shiftedLineCollection.push({
                  shiftedLines: [message.data], 
                  colorIndex: connectionStore.currentColorIndex, 
                });
                connectionStore.currentColorIndex += 1;
              }
              const sendingMessage: IWSMessage = {
                windowIndex: 0,
                newWindowContent: [{
                  content: message.data, 
                  colorIndex: colorIndex, 
                }]
              };
              connectionStore.socket.send(JSON.stringify(sendingMessage))
            }
            else {
              //no connection was found that has previously sent the string -> is a new string, needs to be added
              for (let connection of KWICOperationViewer.connectionList) {
                connection.shiftedLineCollection.push({
                  shiftedLines: [message.data], 
                  colorIndex: connection.currentColorIndex, 
                });
                const sendingMessage: IWSMessage = {
                  windowIndex: 0,
                  newWindowContent: [{
                    content: message.data, 
                    colorIndex: connection.currentColorIndex, 
                  }]
                };
                connection.currentColorIndex += 1;
                connection.socket.send(JSON.stringify(sendingMessage))
              }
            }
            break;
          }
          case KWIC_PROCESSING_STAGE.SHIFTED_LINES: {
            //update the circular shifts window by appending the new content in a different color
            // const singleLine = message.data.split(lineDelimiter)[0];

            //first, get the connection store that has sent the string
            const connectionStore: ConnectionStore | null = KWICOperationViewer.getConnectionStoreOfString(message.data);
            let colorIndex: number = 0;
            //if the connection was found, then assign the color of the line from that
            if (connectionStore !== null) {
              colorIndex = connectionStore.currentColorIndex - 1;
              // colorIndex = KWICOperationViewer.getLineColorInConnectionStore(singleLine, connectionStore);
              // if (colorIndex >= 0) {
                //color is determined for all lines of the connection - send update to frontend
                let windowString: IWSWindowContent[] = [];
                for (let lineCollection of connectionStore.shiftedLineCollection) {
                  windowString.push({
                    content: lineCollection.shiftedLines.join(lineDelimiter),
                    colorIndex: lineCollection.colorIndex, 
                  });
                }
                const messageSending: IWSMessage = {
                  windowIndex: 1,
                  newWindowContent: windowString, 
                }
                connectionStore.socket.send(JSON.stringify(messageSending));
              // }
              // else {
              //   //color unknown for the new lineset - add the lineset to the current socket connectionStore
              //   connectionStore.shiftedLineCollection.push({
              //     colorIndex: connectionStore.currentColorIndex,
              //     shiftedLines: message.data.split(lineDelimiter), 
              //   })
              //   connectionStore.currentColorIndex += 1;

              //   //send update to the frontend
              //   let windowString: IWSWindowContent[] = [];
              //   for (let lineCollection of connectionStore.shiftedLineCollection) {
              //     windowString.push({
              //       content: lineCollection.shiftedLines.join(lineDelimiter), 
              //       colorIndex: lineCollection.colorIndex, 
              //     });
              //   }
              //   const messageSending: IWSMessage = {
              //     windowIndex: 1,
              //     newWindowContent: windowString, 
              //   }
              //   connectionStore.socket.send(JSON.stringify(messageSending));
              // }
            }
            else {
              //line has not been sent yet -> append it to all connections
              for (let connectionStore of KWICOperationViewer.connectionList) {
                connectionStore.shiftedLineCollection.push({
                  colorIndex: connectionStore.currentColorIndex - 1,
                  shiftedLines: message.data.split(lineDelimiter), 
                })
                // connectionStore.currentColorIndex += 1;

                //send update to the frontend
                let windowString: IWSWindowContent[] = [];
                for (let lineCollection of connectionStore.shiftedLineCollection) {
                  windowString.push({
                    content: lineCollection.shiftedLines.join(lineDelimiter), 
                    colorIndex: lineCollection.colorIndex, 
                  });
                }
                const messageSending: IWSMessage = {
                  windowIndex: 1,
                  newWindowContent: windowString, 
                }
                connectionStore.socket.send(JSON.stringify(messageSending));
              }
            }
            break;
          }
          case KWIC_PROCESSING_STAGE.ALPHABETIZED_LINES: {
            //update alphabetic shifts window

            //alphabetizer sends all the sorted lines -> need to color each line individually

            const windowContent: IWSWindowContent[] = [];
            const lines: string[] = message.data.split(lineDelimiter);

            for (let line of lines) {
              //first, get the connection store that has sent the string
              const connectionStore: ConnectionStore | null = KWICOperationViewer.getConnectionStoreOfString(line);
              //if the connection was found, then assign the color of the line from that
              if (connectionStore !== null) {
                windowContent.push({
                  content: line, 
                  colorIndex: Math.max(0, KWICOperationViewer.getLineColorInConnectionStore(line, connectionStore)),
                });
              }
              else {
                windowContent.push({
                  content: line, 
                  colorIndex: 0,
                });
              }
            }

            const messageSending: IWSMessage = {
              windowIndex: 2,
              newWindowContent: windowContent
            }
            // console.log(messageSending);

            for (let connectionStore of KWICOperationViewer.connectionList) {
              connectionStore.socket.send(JSON.stringify(messageSending));
            }
            break;
          }
          default:
            break;
        }
      })
    }

    this.removeListener = () => {
      this.masterControl.removeListener();
    }
  }
}

export default KWICOperationViewer;