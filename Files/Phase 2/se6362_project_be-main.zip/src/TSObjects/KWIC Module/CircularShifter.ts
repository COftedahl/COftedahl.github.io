import { wordDelimiter } from "../constants";
import { KWIC_CLASS, KWIC_PROCESSING_STAGE } from "../Interfaces/IKWICClassProcessingMessage";
import KWICModuleBaseClass from "./KWICModuleBaseClass";
import Listener from "./Listener";

class CircularShifter extends KWICModuleBaseClass {
  private prevObject?: KWICModuleBaseClass;
  private listener: Listener;
  public retrieveLineStorageLines: () => Promise<void>;
  private computeCircularShifts: (wordsInLine: string[]) => Promise<string[]>;

  constructor(prevObject?: KWICModuleBaseClass) {
    super();

    this.prevObject = prevObject;
    this.listener = new Listener();

    this.retrieveLineStorageLines = async () => {
      if (this.prevObject) {
        const numWords: number = await this.prevObject.word(0);
        const words: string[] = [];
        
        let charIndex: number = 0;
        let char: string = '';
        for (let i = 0; i < numWords; i += 1) {
          words.push("");
          charIndex = 0;
          char = await this.prevObject.char(0, i, charIndex);
          while (char !== '') {
            words[i] += char;
            charIndex += 1;
            char = await this.prevObject.char(0, i, charIndex);
          }
        }

        await this.prevObject.removeFirstLine();
        if (words.length > 0) {
          this.listener.sendAlert({
            sourceModule: KWIC_CLASS.CIRCULAR_SHIFTER,
            processingStage: KWIC_PROCESSING_STAGE.UNSHIFTED_LINE,
            data: words.join(wordDelimiter),
          })
        }

        await this.computeCircularShifts(words);
      }
    }

    this.computeCircularShifts = async (wordsInLine: string[]) => {
      const shiftedLines: string[] = [];
      const numWords: number = wordsInLine.length;

      //compute circular shifts
      for (let i = 0; i < numWords; i += 1) {
        shiftedLines.push(wordsInLine.join(wordDelimiter));
        this.listener.sendAlert({
          sourceModule: KWIC_CLASS.INPUT_HANDLER,
          processingStage: KWIC_PROCESSING_STAGE.SHIFTED_LINES,
          data: wordsInLine.join(wordDelimiter)
        })
        const tempWord: string = wordsInLine.shift() as string;
        wordsInLine.push(tempWord);
      }

      await this.persistLines(shiftedLines);

      return shiftedLines;
    }
  }
}

export default CircularShifter;