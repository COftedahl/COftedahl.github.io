import DataMedium from "./DataMedium";

class InputMedium extends DataMedium{}

export default InputMedium;