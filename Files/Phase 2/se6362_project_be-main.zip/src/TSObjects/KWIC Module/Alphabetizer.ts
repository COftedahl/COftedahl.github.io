import mergesort, { merge } from "../../Functions/Mergesort";
import { lineDelimiter, wordDelimiter } from "../constants";
import { KWIC_CLASS, KWIC_PROCESSING_STAGE } from "../Interfaces/IKWICClassProcessingMessage";
import KWICModuleBaseClass from "./KWICModuleBaseClass";
import Listener from "./Listener";

class Alphabetizer extends KWICModuleBaseClass {
  private prevObject?: KWICModuleBaseClass;
  private listener: Listener;
  public retrieveNoiselessLines: () => Promise<void>;
  private computeAlphabeticShifts: (unsortedLines: string[]) => Promise<string[]>;

  constructor(prevObject?: KWICModuleBaseClass) {
    super();

    this.prevObject = prevObject;
    this.listener = new Listener();

    this.retrieveNoiselessLines = async () => {
      if (this.prevObject) {
        let words: string[] = [];
        const lines: string[] = [];
        let numWords: number = await this.prevObject.word(0);
        
        while (numWords > 0) {
          words = [];
          let charIndex: number = 0;
          let char: string = '';
          for (let i = 0; i < numWords; i += 1) {
            charIndex = 0;
            words.push("");
            char = await this.prevObject.char(0, i, charIndex);
            while (char !== '') {
              words[i] += char;
              charIndex += 1;
              char = await this.prevObject.char(0, i, charIndex);
            }
          }
          const newLine: string = words.join(wordDelimiter);
          lines.push(newLine);
          await this.prevObject.removeFirstLine();
          numWords = await this.prevObject.word(0);
        }

        await this.computeAlphabeticShifts(lines);
      }
    }

    this.computeAlphabeticShifts = async (unsortedLines: string[]) => {
      //sort current lines
      const currentSortedLines: string[] = mergesort(unsortedLines);

      //now merge the sorted current lines with the existing sorted lines
      // console.log("Merging: ", this.lines, "\n", currentSortedLines);
      const totalSortedLines: string[] = merge(currentSortedLines, await this.getLines());
      // console.log("Merged: ", totalSortedLines);
      this.listener.sendAlert({
        sourceModule: KWIC_CLASS.ALPHABETIZER,
        processingStage: KWIC_PROCESSING_STAGE.ALPHABETIZED_LINES,
        data: totalSortedLines.join(lineDelimiter)
      })

      await this.resetLines();
      await this.persistLines(totalSortedLines);

      return totalSortedLines;
    }
  }
}

export default Alphabetizer;