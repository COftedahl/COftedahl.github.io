import { Mutex } from "async-mutex";

/* 
 * class to simulate a buffer with read/write capabilities using a singleton to access & a mutex to synchronize read/writes
 */
class DataMedium {
  public read: () => Promise<string>;
  public write: (appendingData: string) => Promise<void>;
  private data: string;
  private mutex: Mutex; //synchronize operations so the singleton isn't called to read & write at same time
  // private static singleton: DataMedium = new DataMedium();
  // public static getSingleton = () => {
    // return DataMedium.singleton;
  // };

  public constructor() {
    this.data = "";
    this.mutex = new Mutex();

    this.read = async () => {
      await this.mutex.acquire();
      const dataCopy = this.data;
      this.data = "";
      this.mutex.release();
      return dataCopy;
    }

    this.write = async (appendingData: string) => {
      await this.mutex.acquire();
      this.data += appendingData;
      this.mutex.release();
      return;
    }
  }
}

export default DataMedium;