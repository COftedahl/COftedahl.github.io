import { Mutex } from "async-mutex";
import { wordDelimiter } from "../constants";

class KWICModuleBaseClass {
  protected mutex: Mutex = new Mutex();
  public lines: string[];

  /* 
   * function to set a single character of one word in one line of the lines field stored in the object
   * @param lineNum: integer representing the (0-indexed) line number
   * @param wordNum: integer representing the (0-indexed) word number (words indicated by space delimiters)
   * @param charNum: integer representing the (0-indexed) character number
   * @param value: character indicating to what value to set the character in the lines object
   */
  public setChar: (lineNum: number, wordNum: number, charNum: number, value: string) => Promise<void>;
  
  /* 
   * function to retrieve a single character of one word in one line of the lines field stored in the object
   * @param lineNum: integer representing the (0-indexed) line number
   * @param wordNum: integer representing the (0-indexed) word number
   * @param charNum: integer representing the (0-indexed) character number
   * @return: character indicating the value of the requested character, or an empty string if the requested character does not exist (e.g. invalid index arguments)
   */
  public char: (lineNum: number, wordNum: number, charNum: number) => Promise<string>;

  /* 
   * function to get the number of words in a line of the lines field stored in the object
   * @param lineNum: integer representing the (0-indexed) line number
   * @return: number indicating the number of words in the requested line, or -1 if the requested line does not exist (e.g. invalid index argument)
   */
  public word: (lineNum: number) => Promise<number>;

  /* 
   * function to save a set of lines using the setChar method
   * @param lines: string array of lines to persist
   */
  protected persistLines: (lines: string[]) => Promise<void>;

  /* 
   * function to reset the lines variable to initial state
   */
  public resetLines: () => Promise<void>;

  /* 
   * function to retrieve the value of the lines variable
   * @return: string array for the value of lines
   */
  public getLines: () => Promise<string[]>;

  /* 
   * function to remove the first line of the lines variable
   */
  public removeFirstLine: () => Promise<void>;

  public constructor() {
    this.lines = [];

    this.setChar = async (lineNum: number, wordNum: number, charNum: number, value: string) => {
      //acquire the mutex b/c accessing the lines object
      await this.mutex.acquire();
      //first check that the line index is valid
      if ((this.lines.length < lineNum) || (lineNum < 0)) {
        this.mutex.release();
        return;
      }

      //check if this is requesting to add a new line
      if (lineNum === this.lines.length) {
        this.lines.push(value);
        this.mutex.release();
        return;
      }

      const words: string[] = this.lines[lineNum].split(wordDelimiter);

      //now check that the word index is valid
      if ((words.length < wordNum) || (wordNum < 0)) {
        this.mutex.release();
        return;
      }

      //check if this is requesting to add a new word
      if (wordNum === words.length) {
        //if charNum !== 0 when adding a new word, consider it invalid
        if (charNum !== 0) {
          this.mutex.release();
          return;
        }
        //here, we know we are adding word to the end of a line
        if (words.length > 0) {
          //if adding word after other words, need to insert a space to split words
          this.lines[lineNum] += wordDelimiter;
        }
        this.lines[lineNum] += value;
        this.mutex.release();
        return;
      }

      //check that the character index is valid
      if ((words[wordNum].length < charNum) || (charNum < 0)) {
        this.mutex.release();
        return;
      }

      //check if this is requesting to append a character to a word
      if (words[wordNum].length === charNum) {
        words[wordNum] += value;
      }
      else {
        //placing char value onto an existing character slot
        words[wordNum] = words[wordNum].substring(0, charNum) + value + words[wordNum].substring(Math.min(charNum + 1, words[wordNum].length), words[wordNum].length)
      }

      //need to now put the changes made in "words" variable and propagate to "lines" variable to persist changes
      this.lines[lineNum] = words.join(wordDelimiter);
      this.mutex.release();
      return;
    }

    this.char = async (lineNum: number, wordNum: number, charNum: number) => {
      //acquire the mutex b/c accessing the lines object
      await this.mutex.acquire();
      //first check that the line index is valid
      if ((this.lines.length <= lineNum) || (lineNum < 0)) {
        this.mutex.release();
        return "";
      }

      const words: string[] = this.lines[lineNum].split(wordDelimiter);

      //now check that the word index is valid
      if ((words.length <= wordNum) || (wordNum < 0)) {
        this.mutex.release();
        return "";
      }

      //now check that the character index is valid
      if ((words[wordNum].length <= charNum) || (charNum < 0)) {
        this.mutex.release();
        return "";
      }

      //we know we have valid index values here
      this.mutex.release();
      return words[wordNum].charAt(charNum);
    }

    this.word = async (lineNum: number) => {
      //acquire the mutex b/c accessing the lines object
      await this.mutex.acquire();
      //first check that the line index is valid
      if ((this.lines.length <= lineNum) || (lineNum < 0)) {
        this.mutex.release();
        return -1;
      }

      this.mutex.release();
      return this.lines[lineNum].split(wordDelimiter).length;
    }

    this.persistLines = async (lines: string[]) => {
      //acquire the mutex b/c accessing the lines object
      await this.mutex.acquire();
      //persist the data
      let lineIndex: number = 0;
      let wordIndex: number = 0;
      let charIndex: number = 0;
      for (let line of lines) {
        wordIndex = 0;
        const wordsInLine: string[] = line.split(wordDelimiter);
        for (let word of wordsInLine) {
          charIndex = 0;
          for (let char of word) {
            this.setChar(lineIndex, wordIndex, charIndex, char);
            charIndex += 1;
          }
          wordIndex += 1;
        }
        lineIndex += 1;
      }
      
      this.mutex.release();
      return;
    }

    this.resetLines = async () => {
      //acquire the mutex b/c accessing the lines object
      await this.mutex.acquire();
      
      this.lines = [];

      this.mutex.release();
      return;
    }

    this.getLines = async () => {
      //acquire the mutex b/c accessing the lines object
      await this.mutex.acquire();
      
      const tempVar: string[] = this.lines;

      this.mutex.release();
      return tempVar;
    }

    this.removeFirstLine = async () => {
      //acquire the mutex b/c accessing the lines object
      this.mutex.acquire();

      if (this.lines.length > 0) {
        this.lines = this.lines.slice(1);
      }

      this.mutex.release();
      return;
    }
  }
}

export default KWICModuleBaseClass;