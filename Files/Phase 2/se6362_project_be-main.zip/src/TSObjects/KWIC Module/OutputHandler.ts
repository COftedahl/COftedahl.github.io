import { lineDelimiter, wordDelimiter } from "../constants";
import KWICModuleBaseClass from "./KWICModuleBaseClass";
import OutputMedium from "./OutputMedium";

class OutputHandler {
  private prevObject?: KWICModuleBaseClass;
  public getAlphabetizedLines: () => Promise<void>;
  public sendOutputLines: (outputLines: string[]) => Promise<void>;

  constructor(outputMedium: OutputMedium, prevObject?: KWICModuleBaseClass) {
    this.prevObject = prevObject;

    this.getAlphabetizedLines = async () => {
      if (this.prevObject) {
        let words: string[] = [];
        const lines: string[] = [];
        let numWords: number = await this.prevObject.word(0);
        
        while (numWords > 0) {
          words = [];
          let charIndex: number = 0;
          let char: string = '';
          for (let i = 0; i < numWords; i += 1) {
            charIndex = 0;
            words.push("");
            char = await this.prevObject.char(0, i, charIndex);
            while (char !== '') {
              words[i] += char;
              charIndex += 1;
              char = await this.prevObject.char(0, i, charIndex);
            }
          }
          const newLine: string = words.join(wordDelimiter);
          lines.push(newLine);
          await this.prevObject.removeFirstLine();
          numWords = await this.prevObject.word(0);
        }

        await this.sendOutputLines(lines);
      }
    }

    this.sendOutputLines = async (outputLines: string[]) => {
      // await OutputMedium.getSingleton().write(outputLines.join(lineDelimiter));
      await outputMedium.write(outputLines.join(lineDelimiter));
    }
  }
}

export default OutputHandler;