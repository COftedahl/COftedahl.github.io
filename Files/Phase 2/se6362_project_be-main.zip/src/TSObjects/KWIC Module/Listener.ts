import { Mutex } from "async-mutex";
import IKWICClassProcessingMessage from "../Interfaces/IKWICClassProcessingMessage";

class Listener {
  private static callback = async (_message: IKWICClassProcessingMessage) => {};
  private static mutex: Mutex = new Mutex();
  private static messageQueue: IKWICClassProcessingMessage[] = [];
  private static messageIntervalTimeMillis: number = 500; //1/2 second between each message 
  private static messageInterval: NodeJS.Timeout | null = null;
  private checkMessageQueue: () => Promise<void>;
  public attachListener: (listener: (message: IKWICClassProcessingMessage) => Promise<void>) => Promise<void>;
  public removeListener: () => Promise<void>;
  public sendAlert: (data: IKWICClassProcessingMessage) => Promise<void>;

  constructor() {
    this.attachListener = async (listener: (message: IKWICClassProcessingMessage) => Promise<void>) => {
      await Listener.mutex.acquire();
      Listener.callback = listener;
      Listener.mutex.release();
    }

    this.removeListener = async () => {
      await Listener.mutex.acquire();
      Listener.callback = async () => {};
      Listener.mutex.release();
    }

    this.sendAlert = async (data: IKWICClassProcessingMessage) => {
      await Listener.mutex.acquire();
      if (Listener.messageInterval) {
        Listener.messageQueue.push(data);
      }
      else {
        await Listener.callback(data);
        Listener.messageInterval = setInterval(() => {
          this.checkMessageQueue();
        }, Listener.messageIntervalTimeMillis);
      }
      Listener.mutex.release();
    }

    this.checkMessageQueue = async () => {
      await Listener.mutex.acquire();
      if (Listener.messageQueue.length > 0) {
        await Listener.callback(Listener.messageQueue.shift() as IKWICClassProcessingMessage);
      }
      else {
        if (Listener.messageInterval) {
          clearInterval(Listener.messageInterval);
          Listener.messageInterval = null;
        }
      }
      Listener.mutex.release();
    }
  }
}

export default Listener;