import DBEntry from "../Schemas/Mongoose/DBEntry";
import IDBEntry, { IDBUrlEntry } from "./Interfaces/IDBEntry";
import {default as DBEntryValidatorSchema } from "../Schemas/ExpressValidator/DBEntry";
import { checkSchema, matchedData, validationResult } from "express-validator";
import IURLTitlePair from "./Interfaces/IURLTitlePair";
import escapeRegex from "../Functions/EscapeRegex";
import { KEYWORD_OPERATOR } from "./Interfaces/HTMLReqInterfaces";
import { wordDelimiter } from "./constants";

class DBInterface {
  /* 
   * function to store a set of circularly shifted lines into the database
   * @param entries: the lines to be shifted
   */
  public storeCircularShiftedLines: (entries: IDBEntry[]) => Promise<void>;

  /* 
   * function to retrieve entries from the database for a search string input
   * @param searchString: the entry which shall be searched for in the database
   * @return: string array of results from the database
   */
  public getSearchPhraseEntries: (searchString: string, caseSensitive?: boolean, keywordOperator?: KEYWORD_OPERATOR) => Promise<IDBUrlEntry[]>;

  /* 
   * function to retrieve autocomplete options stored in the db
   * @return: string array of autocomplete options found in the db
   */
  public getPossibleSearchPhrases: () => Promise<string[]>;

  /* 
   * function to remove entries from the db
   * @param elemRemoving: either a string representing the search string for which all corresponding URLs should be removed, or
   *      an IDBEntry object which indicates which URLs should be removed from the given search string
   */
  public removeDBEntry: (elemRemoving: string | IDBEntry) => Promise<void>;

  /* 
   * function to increment the accessFrequency value associated with a URL in the db
   * @param pair: IURLTitlePair containing the searchString, representing which record the URL will be found under, and the URL to increment within the record
   */
  public incrementAccesses: (pair: IURLTitlePair) => Promise<void>;

  constructor() {
    this.storeCircularShiftedLines = async (entries: IDBEntry[]) => {
      const sanitizedEntries: IDBEntry[] = [];

      //map through entries trying to store, and sanitize each
      for (let entry of entries) {
        const reqObj: {body: IDBEntry} = {body: entry};
        await checkSchema(DBEntryValidatorSchema).run(reqObj);
        const error = validationResult(reqObj);

        if (!error.isEmpty()) {
          console.log(error.mapped());
          console.log("Error in DBInterface_storeCircularShiftedLines entries argument");
          return;
        }

        const sanitizedEntry: IDBEntry = matchedData(reqObj); 
        sanitizedEntries.push(sanitizedEntry);
      }

      //store the sanitized entries in the db
      if (sanitizedEntries.length > 0) {
        for (let sanitizedEntry of sanitizedEntries) {
          const oldURLs: IDBUrlEntry[] = await this.getSearchPhraseEntries(sanitizedEntry.searchString);
          if (oldURLs.length > 0) {
            //modify existing record
            // await DBEntry.updateOne({searchString: sanitizedEntry.searchString}, {searchString: sanitizedEntry.searchString, relatedURLs: [...oldURLs, ...sanitizedEntry.relatedURLs]})
            await DBEntry.updateOne({searchString: sanitizedEntry.searchString}, {searchString: sanitizedEntry.searchString, relatedURLs: sanitizedEntry.relatedURLs})
          }
          else {
            //create new record
            await DBEntry.create(sanitizedEntry);
          }
        }
      }
    }

    this.getSearchPhraseEntries = async (searchString: string, caseSensitive: boolean = true, keywordOperator?: KEYWORD_OPERATOR) => {
      const escaped = escapeRegex(searchString);
      const options: string = (caseSensitive === true ? "m" : "im");
      
      switch(keywordOperator) {
        case KEYWORD_OPERATOR.OR: {
          const regexString: string = escaped.split(wordDelimiter).map((word: string) => "(" + word + ")").join("|");
          const entries: IDBEntry[] | null = await DBEntry.find(
            { searchString: { $regex: "^" + regexString, $options: options } },
            { _id: 0, 'relatedURLs._id': 0 }
          );
          return (entries !== null ? entries.map((entry: IDBEntry) => entry.relatedURLs).flat() : []);
          break;}
        case KEYWORD_OPERATOR.NOT:{
          const entries: IDBEntry[] | null = await DBEntry.find(
            { searchString: { $not: { $regex: "^" + escaped, $options: options } } },
            { _id: 0, 'relatedURLs._id': 0 }
          );
          return (entries !== null ? entries.map((entry: IDBEntry) => entry.relatedURLs).flat() : []);
          break;}
        case KEYWORD_OPERATOR.AND: 
        default: {
          const entry: IDBEntry | null = await DBEntry.findOne(
            { searchString: { $regex: "^" + escaped, $options: options} },
            { _id: 0, 'relatedURLs._id': 0 }
          );
          return (entry !== null ? entry.relatedURLs : []);
          break;}
      }
    }

    this.getPossibleSearchPhrases = async () => {
      return (await DBEntry.find({},{searchString: 1})).map((document: any) => document.searchString)
    }

    this.removeDBEntry = async (elemRemoving: string | IDBEntry) => {
      if ((!(elemRemoving as IDBEntry).relatedURLs) || ((elemRemoving as IDBEntry).relatedURLs.length <= 0)) {
        //elemRemoving is a string
        await DBEntry.deleteOne({searchString: elemRemoving});
      }
      else {
        //elemRemoving is an IDBEntry
        const elemRemovingIDBEntry: IDBEntry = elemRemoving as IDBEntry;
        //first, get the current list of URLs
        const currURLs: IDBUrlEntry[] = await this.getSearchPhraseEntries(elemRemovingIDBEntry.searchString);
        //then, update the list of URLs by removing the URLs passed in elemRemoving
        const newURLs: IDBUrlEntry[] = currURLs.filter((oldURL: IDBUrlEntry) => !elemRemovingIDBEntry.relatedURLs.map((removingEntry: IDBUrlEntry) => removingEntry.url).includes(oldURL.url));
        if (newURLs.length > 0) {
          //if there are still urls left, then update the db
          await DBEntry.updateOne({searchString: elemRemovingIDBEntry.searchString}, {searchString: elemRemovingIDBEntry.searchString, relatedURLs: newURLs});
        }
        else {
          //no urls left, so delete the db entry
          await DBEntry.deleteOne({searchString: elemRemovingIDBEntry.searchString});
        }
      }
      return;
    }

    this.incrementAccesses = async (pair: IURLTitlePair) => {
      const doc: IDBEntry | null = await DBEntry.findOne({searchString: pair.title});
      if (doc == null) {
        return;
      }
      const updatedDoc: IDBEntry = {
        searchString: doc.searchString, 
        relatedURLs: doc.relatedURLs.map((urlEntry: IDBUrlEntry) => {
          return ({
            url: urlEntry.url, 
            accessFrequency: (urlEntry.url === pair.url.url ? urlEntry.accessFrequency + 1 : urlEntry.accessFrequency), 
            paymentValue: urlEntry.paymentValue, 
            dateAdded: urlEntry.dateAdded, 
          })
        })
      }

      await DBEntry.updateOne({searchString: pair.title}, updatedDoc)
    }
  }
}

export default DBInterface;
