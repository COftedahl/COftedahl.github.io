export const lineDelimiter: string = "\n";
export const lineDelimiterReplacementText: RegExp = /\\n/g;
export const wordDelimiter: string = " ";
export const noiseWords: string[] = [
  "A", 
  "And",
  "As",
  "At",
  "But",
  "By",
  "For",
  "In",
  "Is",
  "Nor",
  "Not",
  "Of",
  "On",
  "Or",
  "So",
  "Than",
  "The",
  "To", 
  "With",
  "Which", 
  "Yet",
];
export const WSS_PORT: number = 9000; 
export const dateFormatter: Intl.DateTimeFormat = new Intl.DateTimeFormat('en', {year: 'numeric', month: 'long', day: '2-digit', hourCycle: 'h24', hour: '2-digit', minute: '2-digit', second: '2-digit'});