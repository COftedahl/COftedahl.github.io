import DBInterface from "./DBInterface";
import { IDBUrlEntry } from "./Interfaces/IDBEntry";
import IURLTitlePair from "./Interfaces/IURLTitlePair";
import MasterControl from "./KWIC Module/MasterControl";

class SaveCircularShifts {
  private dbInterface: DBInterface;

  /* 
   * function to compute and store the circular shifts for a set of input lines
   * @param unshiftedLines: array of url + page title pairs (titles = unshifted lines) for which the shifts should be computed and stored
   */
  public storeCircularShifts: (unshiftedLines: IURLTitlePair[]) => Promise<void>;

  /* 
   * function to retrieve the current entries in the database for a given search string
   * @param searchString: the string on which to search the database
   * @return: string array of the entries in the database corresponding to the input string
   */
  public getCurrentURLEntries: (searchString: string) => Promise<IDBUrlEntry[]>;

  /* 
   * function to merge the results of the existing entries in the database with the newly computed line shifts for a given input phrase
   * @param newShiftedLines: string array of the entries to add to the database for a given search string
   * @param oldShiftedLines: string array of the entries in the database corresponding to the given search string
   */
  public appendCircularShifts: (newShiftedLines: IDBUrlEntry[], oldShiftedLines: IDBUrlEntry[]) => IDBUrlEntry[];

  constructor() {
    this.dbInterface = new DBInterface();

    this.storeCircularShifts = async (pairs: IURLTitlePair[]) => {
      const masterControl: MasterControl = new MasterControl();
      for (let pair of pairs) {
        if (pair.url.url.length > 0 && pair.title.length > 0) {
          //compute circular shifts for the current unshifted line
          const shiftedLines: string[] = await masterControl.getCircularShiftedLines([pair.title]);

          //for each shifted line, add the current url to that entry in the db
          for (let shiftedLine of shiftedLines) {
            const existingURLEntries: IDBUrlEntry[] = await this.getCurrentURLEntries(shiftedLine);
            const newURLEntries: IDBUrlEntry[] = this.appendCircularShifts([pair.url], existingURLEntries);
            await this.dbInterface.storeCircularShiftedLines([{
              searchString: shiftedLine,
              relatedURLs: newURLEntries, 
            }])
          }
        }
      }
    }

    this.getCurrentURLEntries = async (searchString: string) => {
      return await this.dbInterface.getSearchPhraseEntries(searchString);
    }

    this.appendCircularShifts = (newShiftedLines: IDBUrlEntry[], oldShiftedLines: IDBUrlEntry[]) => {
      return [...oldShiftedLines, ...newShiftedLines];
    }
  }
}

export default SaveCircularShifts;