import { IDBUrlEntry } from "./IDBEntry";

interface IURLTitlePair {
  title: string, 
  url: IDBUrlEntry, 
}

export default IURLTitlePair;