export enum KEYWORD_OPERATOR {
  AND = "And",
  OR = "Or", 
  NOT = "Not", 
}
export enum SORTING_METHOD {
  ALPHABETICAL = "Alphabetical", 
  MOST_FREQUENTLY_ACCESSED = "Most Frequently Accessed", 
  PAYMENT = "Payment", 
}

export interface ISearchBody {
  searchString: string, 
  useCaseSensitive: boolean, 
  keywordOperator: KEYWORD_OPERATOR, 
  sortingMethod: SORTING_METHOD, 
  reverseSort: boolean, 
}