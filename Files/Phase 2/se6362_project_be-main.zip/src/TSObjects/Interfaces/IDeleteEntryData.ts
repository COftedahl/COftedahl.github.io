interface IDeleteEntryData {
  searchString: string, 
  urls: string[], 
}

export default IDeleteEntryData;