export interface IDBUrlEntry {
  url: string, 
  paymentValue: number, 
  accessFrequency: number, 
  dateAdded: string, 
}

interface IDBEntry {
  searchString: string, 
  relatedURLs: IDBUrlEntry[], 
}

export default IDBEntry;