/* 
 * ******     EBNF SYNTAX FOR URL     ******
 * ******     Convention:             *************************************************************
 *                () ::= grouping                                                                 *
 *                {} ::= repetition of preceding element (number of repetitions inside braces)    *
 *                ?  ::= preceding element is optional                                            *
 *                *  ::= preceding element can occur 0 or more times                              *
 *                +  ::= preceding element can occur 1 or more times                              *
 * ************************************************************************************************
 * URL ::= ('http' ('s')? '://')? identifiers '.' ('edu' | 'com' | 'org' | 'net' | 'gov' | 'eu' | 'uk' | 'in' | 'de') path
 * identifiers ::= (identifier ('.' identifier){0,3}) | (numericIdentifier ('.' numericIdentifier){3})
 * identifier ::= (letter (letter | digit)*)
 * numericIdentifier ::= (digit+) 
 * path ::= '/'? | ('/' char+)+
 * letter ::= ('a' | 'b' | ... | 'y' | 'z' | 'A' | 'B' | ... | 'Y' | 'Z')
 * digit ::= ('1' | '2' | ... | '9' | '0')
 * char ::= letter | digit | '=' | '?' | '&' | '%' | '#' | '*' | '+' | '-' | '_' | '.'
 */

import { isAlpha, isAlphanumeric, isNumeric } from "validator";

class URLParser {

  public static readonly ALLOWED_DOMAINS: ReadonlySet<string> = new Set([
    "edu", 
    "com", 
    "org", 
    "net", 
    "gov", 
    "eu", 
    "uk", 
    "in", 
    "de", 
  ]);

  public static readonly ALLOWED_NON_ALPHANUMERIC_CHARS: ReadonlySet<string> = new Set([
    '=', 
    '?', 
    '&', 
    '%', 
    '#', 
    '*', 
    '+', 
    '-', 
    '_', 
    '.', 
  ])

  private static readonly FAILED_VALIDATION: {valid: boolean, remaining: ""} = {valid: false, remaining: ""};

  private static readonly MAX_IDENTIFIERS: number = 4;

  /* 
   * function to check whether a given string satisfies the URL syntax conditions
   *   required syntax for URL given at beginning of file
   * @input url: string representing a potential url
   * @return: boolean representing whether the input string was a valid url
   */
  public isValidURL: (url: string) => boolean;

  /* 
   * function to check whether the protocol part of the URL exists and is valid, and remove it if it exists
   * @input url: string to check
   * @return: object containing boolean 'valid' indicating if the syntax was satisfied, and string 'remaining' for the remaining part of the URL to parse
   */
  private parseProtocol: (url: string) => {valid: boolean, remaining: string}

  /* 
   * function to check whether the identifiers part of the URL is valid and remove it
   * @input url: string to check
   * @return: object containing boolean 'valid' indicating if the syntax was satisfied, and string 'remaining' for the remaining part of the URL to parse
   */
  private parseIdentifiers: (url: string) => {valid: boolean, remaining: string}

  /* 
   * function to check whether the domain part of the URL is valid and remove it
   * @input url: string to check
   * @return: object containing boolean 'valid' indicating if the syntax was satisfied, and string 'remaining' for the remaining part of the URL to parse
   */
  private parseDomain: (url: string) => {valid: boolean, remaining: string}

  /* 
   * function to check whether the path part of the URL is valid and remove it
   * @input url: string to check
   * @return: object containing boolean 'valid' indicating if the syntax was satisfied, and string 'remaining' for the remaining part of the URL to parse
   */
  private parsePath: (url: string) => {valid: boolean, remaining: string}

  constructor() {
    this.isValidURL = (url: string) => {
      let currStatus: {valid: boolean, remaining: string} = {valid: true, remaining: url};

      currStatus = this.parseProtocol(currStatus.remaining);
      if (!currStatus.valid) {
        return false;
      }

      currStatus = this.parseIdentifiers(currStatus.remaining);
      if (!currStatus.valid) {
        return false;
      }

      currStatus = this.parseDomain(currStatus.remaining);
      if (!currStatus.valid) {
        return false;
      }

      currStatus = this.parsePath(currStatus.remaining);
      if (!currStatus.valid) {
        return false;
      }

      if (currStatus.remaining.length > 0) {
        console.log("failed to parse full url - starting: ", url, " ending: ", currStatus.remaining);
        return false;
      }

      return true;
    }

    //('http' ('s')? '://')?
    this.parseProtocol = (url: string) => {
      //check if the protocol segment exists
      if (url.indexOf("://") < 0) {
        //no protocol segment
        return {valid: true, remaining: url};
      }
      else {
        //protocol segment included
        if (url.substring(0,4) !== 'http') {
          return URLParser.FAILED_VALIDATION;
        }
        else {
          let newURL: string = url.substring(4);
          if (newURL.charAt(0) === 's') {
            newURL = newURL.substring(1);
          }
          if (newURL.substring(0,3) !== '://') {
            return URLParser.FAILED_VALIDATION;
          }
          else {
            newURL = newURL.substring(3);
            return {valid: true, remaining: newURL};
          }
        }
      }
    }

    //identifier ('.' identifier){0,3} '.'
    //identifier ::= (letter (letter | digit)*) | (digit+) 
    this.parseIdentifiers = (url: string) => {
      let numIdentifiersParsed = 0;
      let indexOfDot: number = url.indexOf('.');
      let remainingString: string = url;
      let currIdentifier: string = "";
      let numericIdentifiers: boolean = isNumeric(url.charAt(0));

      while (indexOfDot > 0) {
        currIdentifier = remainingString.substring(0, indexOfDot);
        remainingString = remainingString.substring(indexOfDot + 1);
        indexOfDot = remainingString.indexOf('.');

        if (currIdentifier.length < 1) {
          return URLParser.FAILED_VALIDATION;
        }
        //check whether working with alphanumeric or just digits for identifier
        if (numericIdentifiers) {
          //working with only numeric
          if (!isNumeric(currIdentifier)) {
            return URLParser.FAILED_VALIDATION;
          }
        }
        else {
          //working with alphanumeric
          if (isNumeric(currIdentifier.charAt(0)) || !isAlphanumeric(currIdentifier)) {
            return URLParser.FAILED_VALIDATION;
          }
        }

        numIdentifiersParsed += 1;
        if (numIdentifiersParsed > URLParser.MAX_IDENTIFIERS) {
          return URLParser.FAILED_VALIDATION;
        }
      }
      if (numericIdentifiers && numIdentifiersParsed !== 4) {
        return URLParser.FAILED_VALIDATION;
      }
      return {valid: true, remaining: remainingString};
    }

    //('edu' | 'com' | 'org' | 'net' | 'gov' | 'eu' | 'uk' | 'in' | 'de')
    this.parseDomain = (url: string) => {
      const indexOfSlash: number = url.indexOf('/');
      const startPathIndex: number = indexOfSlash >= 0 ? indexOfSlash : url.length;
      const domainString: string = url.substring(0, startPathIndex);
      const remainingString: string = url.substring(startPathIndex);

      if (URLParser.ALLOWED_DOMAINS.has(domainString)) {
        return {valid: true, remaining: remainingString};
      }
      return URLParser.FAILED_VALIDATION;
    }

    //path ::= '/'? | ('/' char+)+
    this.parsePath = (url: string) => {
      let remainingString: string = url;
      if (remainingString.length <= 0) {
        return {valid: true, remaining: remainingString};
      }

      let indexOfSlash: number = 0;
      let endCurrPathIndex: number = 0;
      let pathString: string = "";

      while (remainingString.length > 0) {
        if (remainingString.charAt(0) == '/') {
          remainingString = remainingString.substring(1);
        }

        indexOfSlash = remainingString.indexOf('/');
        endCurrPathIndex = indexOfSlash >= 0 ? indexOfSlash : remainingString.length;
        pathString = remainingString.substring(0, endCurrPathIndex);
        remainingString = remainingString.substring(endCurrPathIndex);

        while (pathString.length > 0) {
          if (!URLParser.ALLOWED_NON_ALPHANUMERIC_CHARS.has(pathString.charAt(0)) && !isAlphanumeric(pathString.charAt(0)) ) {
            return URLParser.FAILED_VALIDATION;
          }
          pathString = pathString.substring(1);
        }
        
      }

      if (remainingString.length <= 0) {
        return {valid: true, remaining: remainingString};
      }
      return URLParser.FAILED_VALIDATION;
    }
  }
}

export default URLParser;