const ComputingShifts = {
  unshiftedString: {
    isString: true, 
    exists: true, 
    notEmpty: true, 
  }, 
};

export default ComputingShifts;