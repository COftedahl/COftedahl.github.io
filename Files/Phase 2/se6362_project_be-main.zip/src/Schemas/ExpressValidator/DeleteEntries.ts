const DeleteEntries = {
  searchString: {
    isString: true, 
    exists: true, 
    notEmpty: true, 
  }, 
  urls: {
    isArray: true, 
  }, 
  'urls.*': {
    isString: true, 
    exists: true, 
    notEmpty: true, 
  }
};

export default DeleteEntries;