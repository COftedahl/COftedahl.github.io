const IncrementAccesses = {
  searchString: {
    isString: true, 
    exists: true, 
    notEmpty: true, 
  }, 
  url: {
    isString: true, 
    exists: true, 
    notEmpty: true, 
  }, 
};

export default IncrementAccesses;