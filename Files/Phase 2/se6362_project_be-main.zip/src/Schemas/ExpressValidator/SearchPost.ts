import isBoolean from "validator/lib/isBoolean";
import { KEYWORD_OPERATOR, SORTING_METHOD } from "../../TSObjects/Interfaces/HTMLReqInterfaces";

const SearchPost = {
  searchString: {
    isString: true, 
    exists: true, 
    notEmpty: true, 
  }, 
  useCaseSensitive: {
    isBoolean: true, 
    exists: true, 
    notEmpty: true, 
  }, 
  keywordOperator: {
    isString: true, 
    exists: true, 
    notEmpty: true, 
    isIn: {
      options: [
        Object.values(KEYWORD_OPERATOR), 
      ]
    }, 
  }, 
  sortingMethod: {
    isString: true, 
    exists: true, 
    notEmpty: true, 
    isIn: {
      options: [
        Object.values(SORTING_METHOD), 
      ]
    }, 
  }, 
  reverseSort: {
    isBoolean: true, 
    exists: true, 
    notEmpty: true, 
  }, 
}

const SearchPost_Old = {
  searchString: {
    isString: true, 
  }
}

export default SearchPost;