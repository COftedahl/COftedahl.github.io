import mongoose from "mongoose";

const DBEntrySchema = new mongoose.Schema(
  {
    searchString: {
      type: String, 
      require: true, 
    }, 
    relatedURLs: {
      type: [{
        url: {
          type: String, 
          require: true, 
        }, 
        paymentValue: {
          type: Number, 
          require: true, 
        }, 
        accessFrequency: {
          type: Number, 
          require: true, 
        }, 
        dateAdded: {
          type: String, 
          require: true, 
        }
      }], 
      require: true, 
    }
  }
)

const OldDBEntrySchema = new mongoose.Schema(
  {
    searchString: {
      type: String, 
      require: true, 
    }, 
    relatedURLs: {
      type: [String], 
      require: true, 
    }
  }
)

DBEntrySchema.index({searchString: 1})

const DBEntry = mongoose.model("DBEntry", DBEntrySchema, "websites");

export default DBEntry;