import express from 'express';
import { dateFormatter, lineDelimiter, lineDelimiterReplacementText, WSS_PORT } from '../TSObjects/constants';
import DBInterface from '../TSObjects/DBInterface';
import { checkSchema, matchedData, validationResult } from 'express-validator';
import validator from 'validator';
import SearchPost from '../Schemas/ExpressValidator/SearchPost';
import ComputingShifts from '../Schemas/ExpressValidator/ComputingShifts';
import KWICOperationViewer from '../TSObjects/KWICOperationViewer';
import SaveShifts from '../Schemas/ExpressValidator/SaveShifts';
import SaveCircularShifts from '../TSObjects/SaveCircularShifts';
import { ISearchBody } from '../TSObjects/Interfaces/HTMLReqInterfaces';
import { IDBUrlEntry } from '../TSObjects/Interfaces/IDBEntry';
import SortSearchResults from '../Functions/SearchSort';
import DeleteEntries from '../Schemas/ExpressValidator/DeleteEntries';
import IDeleteEntryData from '../TSObjects/Interfaces/IDeleteEntryData';
import URLParser from '../TSObjects/URLParser';
import IncrementAccesses from '../Schemas/ExpressValidator/IncrementAccesses';
import IURLTitlePair from '../TSObjects/Interfaces/IURLTitlePair';

const kwicRouter = express.Router();

//function to get the port to use for websocket connection
kwicRouter.get("/wssport", async (req, res) => {
  const viewer: KWICOperationViewer = new KWICOperationViewer();
  res.status(200).json(WSS_PORT);
})

//function to get autocomplete options
kwicRouter.get("/autocomplete", async (req, res) => {
  const dbInterface: DBInterface = new DBInterface();
  res.status(200).json(await dbInterface.getPossibleSearchPhrases());
})

//function to get search results
kwicRouter.post("/search", async (req, res) => {
  await checkSchema(SearchPost).run(req);
  const error = validationResult(req);

  if (!error.isEmpty()) {
    console.log(error.mapped());
    console.log("Error in KWIC Router_Search");
    return;
  }

  const validatedSearchBody: ISearchBody = matchedData(req); 
  // const validatedSearchString: string = matchedData(req).searchString; 

  const dbInterface: DBInterface = new DBInterface();
  const urls: IDBUrlEntry[] = await dbInterface.getSearchPhraseEntries(
    validatedSearchBody.searchString,
    validatedSearchBody.useCaseSensitive, 
    validatedSearchBody.keywordOperator, 
  );
  const sortedURLs: IDBUrlEntry[] = SortSearchResults(urls, validatedSearchBody.sortingMethod, validatedSearchBody.reverseSort);
  //decode the ampersands used in the stored urls
  const decodedUrls: string[] = sortedURLs.map((url: IDBUrlEntry) => validator.unescape(url.url));
  //decode the actual html entities using the ampersands in the urls
  const decodedUrls2: string[] = decodedUrls.map((url: string) => validator.unescape(url));
  res.status(200).json(decodedUrls2);
})

//function to get circular shifts
kwicRouter.post("/circularshifts", async (req, res) => {
  await checkSchema(ComputingShifts).run(req);
  const error = validationResult(req);

  if (!error.isEmpty()) {
    console.log(error.mapped());
    console.log("Error in KWIC Router_Circular Shifts");
    return;
  }
  
  const validatedSearchString_notReplaced: string = matchedData(req).unshiftedString; 
  const validatedSearchString: string = validatedSearchString_notReplaced.replace(lineDelimiterReplacementText, lineDelimiter)

  const dbInterface: DBInterface = new DBInterface();
  res.status(200).json(await dbInterface.getSearchPhraseEntries(validatedSearchString));
})

//function to view circular shifts computation in real time
kwicRouter.post("/viewcircularshifts", async (req, res) => {
  await checkSchema(ComputingShifts).run(req);
  const error = validationResult(req);

  if (!error.isEmpty()) {
    console.log(error.mapped());
    console.log("Error in KWIC Router_View Circular Shifts");
    return;
  }

  const validatedUnshiftedLines_notReplaced: string = matchedData(req).unshiftedString; 
  const validatedUnshiftedLines: string = validatedUnshiftedLines_notReplaced.replace(lineDelimiterReplacementText, lineDelimiter)

  const viewer: KWICOperationViewer = new KWICOperationViewer();
  const result: string[] = await viewer.viewCircularShiftsRealTime(validatedUnshiftedLines.split(lineDelimiter));
  res.status(200).json(result);
})

//function to compute and save circular shifts
kwicRouter.post("/savecircularshifts", async (req, res) => {
  await checkSchema(SaveShifts).run(req);
  const error = validationResult(req);

  if (!error.isEmpty()) {
    console.log(error.mapped());
    console.log("Error in KWIC Router_Save Circular Shifts");
    return;
  }

  const validatedData = matchedData(req);
  const validatedUnshiftedLines_notReplaced: string = validatedData.unshiftedString; 
  const validatedURLs: string[] = validatedData.urls;
  const validatedUnshiftedLines: string[] = validatedUnshiftedLines_notReplaced.replace(lineDelimiterReplacementText, lineDelimiter).split(lineDelimiter);

  //check that data was sent for both URLs and unshifted lines
  if (validatedURLs.length < 1 || validatedUnshiftedLines.length < 1) {
    res.status(400).json("You must include at least 1 URL and 1 unshifted line in a store shifted lines request");
    return;
  }

  //compare the number of URL's sent to the number of unshifted lines sent
  if ((validatedURLs.length > 1) && (validatedURLs.length !== validatedUnshiftedLines.length)) {
    res.status(400).json("You must provide equal number of URLs and unshifted lines");
    return;
  }

  const urlParser: URLParser = new URLParser();
  for (let url of validatedURLs) {
    if (!urlParser.isValidURL(url)) {
      res.status(400).json("You have provided invalid URLs: " + url);
      return;
    }
  }
  
  const dateString: string = dateFormatter.format();
  
  const saveCircularShifts: SaveCircularShifts = new SaveCircularShifts();
  if (validatedURLs.length === 1) {
    //1 url to apply to every unshifted line sent
    for (let unshiftedLine of validatedUnshiftedLines) {
      await saveCircularShifts.storeCircularShifts([{
        title: unshiftedLine,
        url: {
          url: validatedURLs[0],
          paymentValue: 1.0,
          accessFrequency: 1.0, 
          dateAdded: dateString, 
        }, 
      }])
    }
  }
  else {
    //each unshifted line has its own url
    let currIndex: number = 0;
    for (let unshiftedLine of validatedUnshiftedLines) {
      await saveCircularShifts.storeCircularShifts([{
        title: unshiftedLine,
        url: {
          url: validatedURLs[currIndex],
          paymentValue: 1.0,
          accessFrequency: 1.0, 
          dateAdded: dateString, 
        }, 
      }])
      currIndex += 1;
    }
  }

  res.status(200).json("Lines stored");
})


//function to delete an entry from the db
kwicRouter.post("/deleteentry", async (req, res) => {
  await checkSchema(DeleteEntries).run(req);
  const error = validationResult(req);

  if (!error.isEmpty()) {
    console.log(error.mapped());
    console.log("Error in KWIC Router_Delete Entries");
    return;
  }

  const validatedData: IDeleteEntryData = matchedData(req);
  const dbInterface: DBInterface = new DBInterface();

  await dbInterface.removeDBEntry({
    searchString: validatedData.searchString, 
    relatedURLs: validatedData.urls.map((url: string) => {return{
      url: url, 
      paymentValue: 1.0, 
      accessFrequency: 1.0,
      dateAdded: "", 
    }}), 
  })

  res.json("Deleted entries");
})

//function to increment the accesses number for a URL
kwicRouter.post("/incrementaccesses", async (req, res) => {
  await checkSchema(IncrementAccesses).run(req);
  const error = validationResult(req);

  if (!error.isEmpty()) {
    console.log(error.mapped());
    console.log("Error in KWIC Router_Increment Accesses");
    return;
  }

  const validatedData: {searchString: string, url: string} = matchedData(req);
  const dbInterface: DBInterface = new DBInterface();
  await dbInterface.incrementAccesses({title: validatedData.searchString, url: {url: validatedData.url, accessFrequency: 1, paymentValue: 1, dateAdded: ""}});
  res.json("Incremented Accesses");
})

export default kwicRouter;
