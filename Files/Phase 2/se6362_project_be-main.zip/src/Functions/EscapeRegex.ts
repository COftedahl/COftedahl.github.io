/** escape user input for safe, literal regex */
const escapeRegex = (s: string): string =>
  s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export default escapeRegex;