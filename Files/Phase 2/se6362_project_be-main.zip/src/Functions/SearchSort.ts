import { SORTING_METHOD } from "../TSObjects/Interfaces/HTMLReqInterfaces";
import { IDBUrlEntry } from "../TSObjects/Interfaces/IDBEntry";

const SortSearchResults = (resultSet: IDBUrlEntry[], sortMethod: SORTING_METHOD, reverseSort: boolean): IDBUrlEntry[] => {
  const reverseSortNum: number = reverseSort ? -1 : 1;
  switch (sortMethod) {
    case SORTING_METHOD.ALPHABETICAL:
      return sortAlphabetical(resultSet, reverseSortNum);
      break;
    case SORTING_METHOD.MOST_FREQUENTLY_ACCESSED: 
      return sortFrequentAccessed(resultSet, reverseSortNum);
      break;
    case SORTING_METHOD.PAYMENT: 
      return sortPayment(resultSet, reverseSortNum);
      break;
    default: 
      return resultSet;
      break;
  }
}

const sortAlphabetical = (resultSet: IDBUrlEntry[], reverseSortNum: number): IDBUrlEntry[] => {
  resultSet.sort((a: IDBUrlEntry, b: IDBUrlEntry) => (a.url > b.url) ? 1 * reverseSortNum : -1 * reverseSortNum);
  return resultSet;
}

const sortFrequentAccessed = (resultSet: IDBUrlEntry[], reverseSortNum: number): IDBUrlEntry[] => {
  resultSet.sort((a: IDBUrlEntry, b: IDBUrlEntry) => (a.paymentValue - b.paymentValue) * reverseSortNum)
  return resultSet;
}

const sortPayment = (resultSet: IDBUrlEntry[], reverseSortNum: number): IDBUrlEntry[] => {
  resultSet.sort((a: IDBUrlEntry, b: IDBUrlEntry) => (a.accessFrequency - b.accessFrequency) * reverseSortNum)
  return resultSet;
}

export default SortSearchResults;