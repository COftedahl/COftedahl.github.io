Run project with "npm start"

# test string: abc def ghi\naab aba abb\naaa bbb ccc\nbaa bab bba\nace car cab\nash arc ape\naid ail aim\narm all\nbar bet bat\nban bam ball\ncam car cash
# test url: https://coftedahl.github.io/



//Search Strings to test AND/OR/NOT and case sensitive: 
//AND + Sensitive: team website | team Website
//OR + Sensitive: a | A
//NOT + Sensitive: a | A
//AND + Insensitive: ABC
//OR + Insensitive: AB | A B | c | a c
//NOT + Insensitive: a | aB | aBcD



//Search Strings to test ignoring noise words: 
//Case Insensitive: A team with a website which is so to
//Case Sensitive: A team website | a team website