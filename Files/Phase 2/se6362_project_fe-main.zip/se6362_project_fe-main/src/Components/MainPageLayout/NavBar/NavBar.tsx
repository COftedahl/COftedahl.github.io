import { NavLink } from "react-router-dom";
import './NavBar.css';

export interface Tab {
  name: string, 
  route: string, 
}

interface NavBarProps {
  tabs: Tab[], 
}

const NavBar: React.FC<NavBarProps> = (props: NavBarProps) => {

  return (
    <div className="NavBarDiv borderBox flexRow fullWidth ">
      {props.tabs.map((tab: Tab, index: number) => {
        return (
          <NavLink 
            to={tab.route} 
            key={index}
            className={({isActive}) => {return "NavBar_Link padding1 flexRow centerJustify centerAlign hideScrollbars" + (isActive ? " NavBar_Link-active" : "")}}
          >
            {tab.name}
          </NavLink>
        )
      })}
    </div>
  );
}

export default NavBar;