import { useSearchParams } from "react-router-dom";
import InputBar from "../../../Utility/InputBar/InputBar";
import { useEffect, useState, type FormEvent } from "react";
import { saveCircularShiftsParams_lines } from "../../../Constants/frontendroutes";
import { BACKEND_URL, KWIC_ROUTE, KWIC_SHIFT_SAVER } from "../../../Constants/backendroutes";
import { FETCH_POST_OPTIONS } from "../../../Constants/fetchCallHeaders";
import { lineDelimiter, lineDelimiterReplacementText } from "../../../Constants/delimiters";

interface SaveShiftsPageProps {

}

const SaveShiftsPage: React.FC<SaveShiftsPageProps> = (_props: SaveShiftsPageProps) => {

  let [searchParams] = useSearchParams();
  const URL_INPUT_ERROR_CLASSNAME: string = "StoreShiftsForm_URL-error";
  const LINES_INPUT_ERROR_CLASSNAME: string = "StoreShiftsForm_Lines-error";

  const [errorText, setErrorText] = useState<string>("");
  const [urlInputValue, setURLInputValue] = useState<string>("");
  const [linesInputValue, setLinesInputValue] = useState<string>("");
  const [urlInputErrorClassValue, setURLInputErrorClassValue] = useState<string>("");
  const [linesInputErrorClassValue, setLinesInputErrorClassValue] = useState<string>("");
  const [hasStoredLines, setHasStoredLines] = useState<boolean>(false);
  const [hasSubmittedSaveReq, setHasSubmittedSaveReq] = useState<boolean>(false);
  const [hasReceievedResponse, setHasReceivedResponse] = useState<boolean>(false);

  const handlePageOpened = () => {
    if (linesInputValue.length < 1) {
      setLinesInputValue(searchParams.get(saveCircularShiftsParams_lines) || "");
    }
    setHasStoredLines(false);
    setHasSubmittedSaveReq(false);
    setHasReceivedResponse(false);
  }

  const handleURLInputChanged = (e: React.ChangeEvent) => {
    setURLInputErrorClassValue("");
    setURLInputValue((e.target as any).value);
    setHasStoredLines(false);
    setHasSubmittedSaveReq(false);
    setHasReceivedResponse(false);
  }

  const handleLinesInputChanged = (e: React.ChangeEvent) => {
    setLinesInputErrorClassValue("");
    setLinesInputValue((e.target as any).value);
    setHasStoredLines(false);
    setHasSubmittedSaveReq(false);
    setHasReceivedResponse(false);
  }

  const handleFormSubmitted = async (e?: FormEvent) => {
    if (e) {
      e.preventDefault();
    }

    setHasStoredLines(false);
    setHasSubmittedSaveReq(false);
    setHasReceivedResponse(false);

    
    setErrorText("");
    if ((urlInputValue.length < 1) || (linesInputValue.length < 1)) {
      if (urlInputValue.length < 1) {
        setURLInputErrorClassValue(URL_INPUT_ERROR_CLASSNAME);
        setErrorText("You must provide a value for the url field");
      }
      if (linesInputValue.length < 1) {
        setLinesInputErrorClassValue(LINES_INPUT_ERROR_CLASSNAME);
        if (errorText.length > 1) {
          setErrorText((existingText: string) => existingText + " and you must provide a value for the lines field")
        }
        else {
          setErrorText("You must provide a value for the lines field");
        }
      }
      return;
    }
    setHasSubmittedSaveReq(true);
    try {
      const res = await fetch(BACKEND_URL + KWIC_ROUTE + KWIC_SHIFT_SAVER, {
      // const res = await fetch(BACKEND_URL + "/abc", {
        // method: "GET", 
        method: "POST", 
        body: JSON.stringify({
          unshiftedString: linesInputValue, 
          urls: urlInputValue.replace(lineDelimiterReplacementText, lineDelimiter).split(lineDelimiter),
        }), 
        ...FETCH_POST_OPTIONS,
      }).then((res) => res.status === 200 ? res as any : res.text());

      setHasSubmittedSaveReq(false);
      setHasReceivedResponse(true);
      
      if (res.status === 200) {
        setHasStoredLines(true);
      }

      console.log(res);
    }
    catch (e) {
      setHasSubmittedSaveReq(false);
      setHasReceivedResponse(true);
      setHasStoredLines(false);
      console.error(e);
    }
  }

  useEffect(() => {
    handlePageOpened();
  }, [])

  return (
    <div>
      <p className="StoreShifts_ErrorText">
        {errorText}
      </p>
      <form className="StoreShiftsForm flexColumn fullWidth fullHeight padding1 borderBox gap1" onSubmit={handleFormSubmitted}>
        <InputBar
          containerClassName={"StoreShiftsForm_URL" + " " + urlInputErrorClassValue}
          labelText="URL (separate lines with \n): "
          inputOnChange={handleURLInputChanged}
          inputValue={urlInputValue}
          inputPlaceholder="enter url for page"
          hideButton
        />
        <InputBar
          containerClassName={"StoreShiftsForm_Lines" + " " + linesInputErrorClassValue}
          labelText="Lines to shift (separate lines with \n): "
          inputOnChange={handleLinesInputChanged}
          inputValue={linesInputValue}
          inputPlaceholder="enter lines to shift"
          hideButton
        />
        <div className="StoreShiftsForm_ButtonDiv flexRow fullWidth centerJustify padding1 borderBox">
          <button className={"StoreShiftsForm_Button button wideButton" + (hasStoredLines || hasSubmittedSaveReq ? " StoreShiftsForm_Button-disabled disabled" : "")} disabled={hasStoredLines || hasSubmittedSaveReq}>
            { hasSubmittedSaveReq && !hasReceievedResponse && !hasStoredLines ? 
              "Saving Shifts"
              :
              ( hasStoredLines
                ?
                "Shifts Stored"
                :
                ( hasReceievedResponse
                  ?
                  "Failed to Save Shifts"
                  :
                  "Save Shifts"
                )
              )
            }
          </button>
        </div>
      </form>
    </div>
    
  );
}

export default SaveShiftsPage;