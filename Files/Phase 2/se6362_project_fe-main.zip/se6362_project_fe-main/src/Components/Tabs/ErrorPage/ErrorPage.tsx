
interface ErrorPageProps {

}

const ErrorPage: React.FC<ErrorPageProps> = (_props: ErrorPageProps) => {

  return (
    <p className="ErrorPage_Text fullWidth fullHeight borderBox flexColumn centerJustify centerAlign textAlignCenter">
      Looks like you've requested a page that doesn't exist! Use the top buttons to navigate to the page you'd like. 
    </p>
  );
}

export default ErrorPage;