import { useState } from 'react';
import { KEYWORD_OPERATOR, SORTING_METHOD } from '../SearchPage';
import InputBar from '../../../../Utility/InputBar/InputBar';
import './SettingsPopup.css'

interface SettingsPopupProps {
  active: boolean, 
  closePopup: () => void, 
  isCaseSensitive: boolean, 
  switchIsCaseSensitive: () => void, 
  keywordOperator: KEYWORD_OPERATOR, 
  setKeywordOperator: (value: KEYWORD_OPERATOR) => void, 
  sortingMethod: SORTING_METHOD, 
  setSortingMethod: (value: SORTING_METHOD) => void, 
  reverseSort: boolean, 
  switchReverseSort: () => void, 
  noiseWords: string[], 
  setNoiseWords: (newNoiseWords: string[]) => void, 
}

const SettingsPopup: React.FC<SettingsPopupProps> = (props: SettingsPopupProps) => {

  const [isCaseSensitive, setIsCaseSensitive] = useState<boolean>(props.isCaseSensitive);
  const [keywordOperator, setKeywordOperator] = useState<KEYWORD_OPERATOR>(props.keywordOperator);
  const [sortingMethod, setSortingMethod] = useState<SORTING_METHOD>(props.sortingMethod);
  const [reverseSort, setReverseSort] = useState<boolean>(props.reverseSort);
  const [activeTabIndex, setActiveTabIndex] = useState<0 | 1>(0);
  const [currNoiseWords, setCurrNoiseWords] = useState<string[]>(JSON.parse("" + JSON.stringify(props.noiseWords)));
  const [selectedNWIndex, setSelectedNWIndex] = useState<number>(0);
  const [addNWInputValue, setAddNWInputValue] = useState<string>("");

  const stopPropagation = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
  }

  const resetValues = () => {
    setIsCaseSensitive(props.isCaseSensitive);
    setKeywordOperator(props.keywordOperator);
    setSortingMethod(props.sortingMethod);
    setReverseSort(props.reverseSort);
    setCurrNoiseWords(JSON.parse("" + JSON.stringify(props.noiseWords)));
    setAddNWInputValue("");
    setSelectedNWIndex(0);
  }

  const handleBackgroundClicked = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    //after the popup closes, reset the values to the state passed in as props
    setTimeout(() => {
      resetValues();
    }, 500)
    props.closePopup();
  }

  const handleSettingsSaveClicked = () => {
    if (isCaseSensitive !== props.isCaseSensitive) {
      props.switchIsCaseSensitive();
    }
    props.setKeywordOperator(keywordOperator);
    props.setSortingMethod(sortingMethod);
    if (reverseSort !== props.reverseSort) {
      props.switchReverseSort();
    }
    props.closePopup();
  }

  const handleTabClicked = (tabNumber: 0 | 1) => {
    if (tabNumber !== activeTabIndex) {
      resetValues();
    }
    setActiveTabIndex(tabNumber);
  }

  const handleNWSelectorChanged = (e: React.ChangeEvent) => {
    setSelectedNWIndex((e.target as any).value);
  }

  const handleRemoveSelectedWordClicked = () => {
    if (currNoiseWords.length > selectedNWIndex) {
      currNoiseWords.splice(selectedNWIndex, 1);
      setCurrNoiseWords((_oldNoiseWords) => JSON.parse("" + JSON.stringify(currNoiseWords)));
      if (currNoiseWords.length === 1) {
        setSelectedNWIndex(0);
      }
      else if (currNoiseWords.length === 0) {
        setSelectedNWIndex(-1);
      }
      else {
        setSelectedNWIndex(Math.min(selectedNWIndex, currNoiseWords.length - 1));
      }
    }
  }

  const handleAddNWInputValueChanged = (e: React.ChangeEvent) => {
    setAddNWInputValue((e.target as any).value);
  }

  const handleAddNWClicked = (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
    }
    if (addNWInputValue.length > 0 && !currNoiseWords.includes(addNWInputValue)) {
      currNoiseWords.push(addNWInputValue);
      setAddNWInputValue("");
      setSelectedNWIndex(currNoiseWords.length - 1);
    }
  }

  const handleNWSaveClicked = () => {
    props.setNoiseWords(currNoiseWords);
    props.closePopup();
  }

  return (
    <div 
      className={"SettingsPopupDiv fullScreen popup positionFixed fullWidth fullHeight flexColumn centerJustify centerAlign" + (props.active ? "" : " SettingsPopupDiv-hidden")}
      onClick={handleBackgroundClicked}
    >
      <div className="SettingsPopup_TabWithContentDiv" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
        <div className="SettingsPopup_TabsDiv flexRow fullWidth leftJustify">
          <p className={"SettingsPopup_Tabs_Tab SettingsPopup_Tabs_TabSettings" + (activeTabIndex === 0 ? " SettingsPopup_Tabs_Tab-active" : "")} onClick={() => handleTabClicked(0)}>
            Settings
          </p>
          <p className={"SettingsPopup_Tabs_Tab SettingsPopup_Tabs_TabNoiseWords" + (activeTabIndex === 1 ? " SettingsPopup_Tabs_Tab-active" : "")} onClick={() => handleTabClicked(1)}>
            Configure Noise Words
          </p>
        </div>
        <div className="SettingsPopupContentDiv card">
          {
            activeTabIndex === 0 && 
            <>
              <label className="SettingsPopupContent_Label SettingsPopupContent_LabelCaseSensitive label" onClick={stopPropagation}>
              <p>
                Case Sensitive Search
              </p>
              <input className="SettingsPopupContent_Input SettingsPopupContent_InputCaseSensitive" type="checkbox" key={"" + isCaseSensitive} checked={isCaseSensitive} onChange={(e: React.ChangeEvent) => {stopPropagation(e); setIsCaseSensitive(!isCaseSensitive)}}/>
            </label>
            <br/>
            <label className="SettingsPopupContent_Label SettingsPopupContent_LabelKeywordOperator label" onClick={stopPropagation}>
              <p>
                Keyword Operator
              </p>
              <div className="SettingsPopupContent_Label_OptionGrouper SettingsPopupContent_LabelKeywordOperator_OptionGrouper" onClick={stopPropagation}>
                {
                  Object.values(KEYWORD_OPERATOR).map((value: string, index: number) => {
                    return (
                      <button
                        type="button"
                        key={index}
                        className={"SettingsPopupContent_Button SettingsPopupContent_ButtonKeywordOperator " + (keywordOperator === value ? " SettingsPopupContent_Button-active" : "")}
                        onClick={(e: React.MouseEvent) => {e.preventDefault(); e.stopPropagation(); setKeywordOperator(value as any); }}
                      >
                        {value}
                      </button>
                    )
                  })
                }
              </div>
            </label>
            <br/>
            <label className="SettingsPopupContent_Label SettingsPopupContent_LabelSortingMethod label" onClick={stopPropagation}>
              <p>
                Sorting Method
              </p>
              <select 
                onChange={(e: React.ChangeEvent) => {setSortingMethod((e.target as any).value)}}
                className="SettingsPopupContent_Select SettingsPopupContent_SelectSortingMethod select"
                value={sortingMethod}
              >
                {
                  Object.values(SORTING_METHOD).map((value: string, index: number) => {
                    return (
                      <option key={index} >
                        {value}
                      </option>
                    )
                  })
                }
              </select>
            </label>
            <br/>
            <label className="SettingsPopupContent_Label SettingsPopupContent_LabelReverseSort label" onClick={stopPropagation}>
              <p>
                Reverse Sort Order
              </p>
              <input className="SettingsPopupContent_Input SettingsPopupContent_InputReverseSort" type="checkbox" key={"rv" + reverseSort} checked={reverseSort} onChange={(e: React.ChangeEvent) => {stopPropagation(e); setReverseSort(!reverseSort)}}/>
            </label>
            <div className="SettingsPopupContent_ButtonsDiv flexRow spaceBetweenJustify">
              <button 
                className="SettingsPopupContent_Buttons_Button SettingsPopupContent_Buttons_ButtonClose button"
                onClick={handleBackgroundClicked}
              >
                Close
              </button>
              <button 
                className="SettingsPopupContent_Buttons_Button SettingsPopupContent_Buttons_ButtonSave button"
                onClick={handleSettingsSaveClicked}
              >
                Save
              </button>
            </div>
          </>
          }
          {
            activeTabIndex === 1 && 
            <>
              <div className="flexRow spaceBetweenJustify fullWidth gap1">
                <select className="SettingsPopupContent_NW_WordSelector flexGrow1" value={selectedNWIndex} onChange={handleNWSelectorChanged}>
                  {currNoiseWords.map((noiseWord: string, index: number) => {
                    return (
                      <option key={index} value={index}>
                        {noiseWord}
                      </option>
                    )
                  })}
                </select>
                <button
                  className="SettingsPopupContent_NW_ButtonRemoveSelected button"
                  type="button"
                  onClick={handleRemoveSelectedWordClicked}
                >
                  Remove Selected Noise Word
                </button>
              </div>
              <br/>
              <form onSubmit={handleAddNWClicked}>
                <InputBar
                  labelClassName=''
                  labelText="Noise Word to Add: "
                  inputValue={addNWInputValue}
                  inputOnChange={handleAddNWInputValueChanged}
                  inputPlaceholder="New Noise Word Here"
                  buttonClassName=''
                  buttonText="Add new noise word"
                  buttonOnClick={handleAddNWClicked}
                />
              </form>
              


              <div className="SettingsPopupContent_ButtonsDiv flexRow spaceBetweenJustify">
              <button 
                className="SettingsPopupContent_Buttons_Button SettingsPopupContent_Buttons_ButtonClose button"
                onClick={handleBackgroundClicked}
              >
                Close
              </button>
              <button 
                className="SettingsPopupContent_Buttons_Button SettingsPopupContent_Buttons_ButtonSave button"
                onClick={handleNWSaveClicked}
              >
                Save
              </button>
            </div>
            </>
          }
        </div>
      </div>
    </div>
  );
}

export default SettingsPopup;