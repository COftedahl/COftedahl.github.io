import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import InputBar from '../../../Utility/InputBar/InputBar';
import { BACKEND_URL, KWIC_AUTOCOMPLETES, KWIC_INCREMENTER, KWIC_ROUTE, KWIC_SEARCH_RESULTS } from '../../../Constants/backendroutes';
import { FETCH_POST_OPTIONS } from '../../../Constants/fetchCallHeaders';
import Paginator from '../../../Utility/Paginator/Paginator';
import SettingsPopup from './SettingsPopup/SettingsPopup';
// import { useNavigate } from 'react-router-dom';
import './SearchPage.css';
import { noiseWords } from '../../../Constants/noiseWords';
import { SEARCH_LOAD_WAIT_DURATION, SEARCH_TIMEOUT_DURATION } from '../../../Constants/timeouts';
import { wordDelimiter } from '../../../Constants/delimiters';
import escapeRegex from '../../../Functions/EscapeRegex';

interface SearchPageProps {

}

export enum KEYWORD_OPERATOR {
  AND = "And",
  OR = "Or", 
  NOT = "Not", 
}
export enum SORTING_METHOD {
  ALPHABETICAL = "Alphabetical", 
  MOST_FREQUENTLY_ACCESSED = "Most Frequently Accessed", 
  PAYMENT = "Payment", 
}

const SearchPage: React.FC<SearchPageProps> = (_props: SearchPageProps) => {

  // const navigate = useNavigate();

  const [autocompleteOptions, setAutocompleteOptions] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState<string>("");
  const [inputValueOfDisplayingResults, setInputValueOfDisplayingResults] = useState<string>("");
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [_hasSearched, setHasSearched] = useState<boolean>(false);
  const [hasReceivedResponse, setHasReceivedResponse] = useState<boolean>(false);
  const [paginatorPage, setPaginatorPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(2);
  const [showSettingsPopup, setShowSettingsPopup] = useState<boolean>(false);
  const [caseSensitive, setCaseSensitive] = useState<boolean>(true);
  const [keywordOperator, setKeywordOperator] = useState<KEYWORD_OPERATOR>(KEYWORD_OPERATOR.AND);
  const [sortingMethod, setSortingMethod] = useState<SORTING_METHOD>(SORTING_METHOD.ALPHABETICAL);
  const [reverseSort, setReverseSort] = useState<boolean>(false);
  const [noiseWordsList, setNoiseWordsList] = useState<string[]>(JSON.parse(JSON.stringify(noiseWords)));
  const [showLoadingScreen, setShowLoadingScreen] = useState<boolean>(false);
  const [_loadingScreenTimer, setLoadingScreenTimer] = useState<NodeJS.Timeout | null>(setTimeout(() => {}, 1000));
  const [_searchTimeoutTimer, setSearchTimeoutTimer] = useState<NodeJS.Timeout | null>(setTimeout(() => {}, 1000));

  const handleInputChange = (e: ChangeEvent) => {
    setInputValue((e.target as any).value)
  }

  const getSearchResults = async (searchString?: string) => {
    return await fetch(BACKEND_URL + KWIC_ROUTE + KWIC_SEARCH_RESULTS, {
      method: "POST", 
      body: JSON.stringify({
        searchString: (searchString && searchString.length > 0 ? searchString : inputValue), 
        useCaseSensitive: caseSensitive, 
        keywordOperator: keywordOperator, 
        sortingMethod: sortingMethod, 
        reverseSort: reverseSort, 
      }), 
      ...FETCH_POST_OPTIONS, 
    }).then((res) => res.json());
  }

  const filterNoiseWords = (searchString: string, noiseWords: string[], ignoreCase: boolean): string => {
    const searchStringWords: string[] = searchString.split(wordDelimiter);
    let updatedSearchString: string = "";

    if (ignoreCase === true) {
      updatedSearchString = searchStringWords.filter((searchStringWord: string) => noiseWords.reduce<boolean>((aggregatedValue: boolean, currNoiseWord: string) => {
        return aggregatedValue || new RegExp("^" + escapeRegex(searchStringWord) + "$", "i").test(escapeRegex(currNoiseWord));
      },false) === false).join(wordDelimiter);
    }
    else {
      updatedSearchString = searchStringWords.filter((searchStringWord: string) => noiseWords.includes(searchStringWord) === false).join(wordDelimiter);
    }
    return updatedSearchString;
  }

  const handleSearchClicked = async (e?: FormEvent) => {
    if (e) {
      e.preventDefault();
    }
    if (inputValue.length > 0) {
      setHasSearched(true);
      setHasReceivedResponse(false);
      // setLoadingScreenTimer(setTimeout(() => {
      //   if (!hasReceivedResponse) {
      //     setShowLoadingScreen(true);
      //     setSearchTimeoutTimer(setTimeout(() => {
      //       if (!hasReceivedResponse) {
      //         setShowLoadingScreen(false);
      //         setHasSearched(false);
      //         setInputValue("Error retrieving search results");
      //       }
      //     }, SEARCH_TIMEOUT_DURATION))
      //   }
      // }, SEARCH_LOAD_WAIT_DURATION));
      setInputValueOfDisplayingResults(inputValue);
      const filteredInputs: string = filterNoiseWords(inputValue, noiseWordsList, !caseSensitive);
      const results = await getSearchResults(filteredInputs);
      setHasReceivedResponse(true);
      // setSearchTimeoutTimer(null);
      // setLoadingScreenTimer(null);
      // setTimeout(() => {
      //   setSearchTimeoutTimer(null);
      //   setLoadingScreenTimer(null);
      // }, 100);
      setSearchResults(results);
      setShowLoadingScreen(false);
    }
    else {
      setInputValueOfDisplayingResults("");
      setSearchResults([]);
    }
    
    // setSearchResults(["a", "b", "c", "d", "e", "f", "g"]);
  }

  const getAutocompleteOptions = async () => {
    if (autocompleteOptions.length < 1) {
      console.log("Fetching autocompletes");
      const result: string[] = await fetch(BACKEND_URL + KWIC_ROUTE + KWIC_AUTOCOMPLETES, {
        method: "GET"
      }).then((res) => res.json());
      setAutocompleteOptions(result);
    }
  }

  const handleSearchResultLinkClicked = async (e: React.MouseEvent, target: string) => {
    e.preventDefault();

    //increment the accesses of a URL
    fetch(BACKEND_URL + KWIC_ROUTE + KWIC_INCREMENTER, {
      method: "POST", 
      body: JSON.stringify({
        searchString: inputValueOfDisplayingResults, 
        url: target, 
      }), 
      ...FETCH_POST_OPTIONS, 
    }).then((res) => console.log(res.json()));

    window.open(target, '_blank');
  }
  
  useEffect(() => {
    getAutocompleteOptions();
  }, [])

  return (
    <div className="SearchDiv flexColumn fullHeight fullWidth">
      <div className="Search_SearchbarDiv flexRow">
        <form className="flexGrow1" action="" onSubmit={handleSearchClicked}>
          <InputBar
            containerClassName="Search_Searchbar"
            inputClassName="Search_Searchbar_Input"
            inputPlaceholder="enter search text here"
            buttonText="Search"
            buttonClassName="Search_Searchbar_Button"
            autocompleteListName="SearchbarOptions"
            autocompleteOptions={autocompleteOptions}
            inputValue={inputValue}
            inputOnChange={handleInputChange}
            buttonOnClick={handleSearchClicked}
          />
        </form>
        <button className="Search_Searchbar_SettingsIcon button flexColumn centerAlign centerJustify" onClick={() => setShowSettingsPopup(true)}>
          &#9881;
        </button>
      </div>
      {
        searchResults.length > 0 && 
        <Paginator 
          items={searchResults.map((url: string, index: number) => {
            return (
              <a className="SearchResult_Link" key={index} onClick={(e) => handleSearchResultLinkClicked(e, url)}>
                {url}
              <br/>
              </a>
            )
          })} 
          currentPage={paginatorPage} 
          pageChange={setPaginatorPage}
          itemsPerPage={itemsPerPage}
          setItemsPerPage={(newNumItems: number) => setItemsPerPage(Math.max(0, newNumItems))}
        />
      }
      {/* {
        searchResults.map((url: string, index: number) => {
          return (
            <a key={index} href={url}>
              {url}
            </a>
          )
        })
      } */}
      {
        <div className={"loaderContainer fullWidth fullHeight positionAbsolute topLeft flexColumn centerAlign centerJustify" + (showLoadingScreen ? "" : " loader-hidden")}>
          <div className={"loader " + (showLoadingScreen ? "" : " loader-hidden")}/>
        </div>
      }
      <SettingsPopup 
        active={showSettingsPopup}
        closePopup={() => setShowSettingsPopup(false)}
        isCaseSensitive={caseSensitive}
        switchIsCaseSensitive={() => { setCaseSensitive(() => !caseSensitive); } }
        keywordOperator={keywordOperator}
        setKeywordOperator={setKeywordOperator}
        sortingMethod={sortingMethod}
        setSortingMethod={setSortingMethod}
        reverseSort={reverseSort}
        switchReverseSort={() => setReverseSort((oldValue: boolean) => !oldValue)} 
        noiseWords={JSON.parse("" + JSON.stringify(noiseWordsList))} 
        setNoiseWords={setNoiseWordsList}
      />
    </div>
  );
}

export default SearchPage;