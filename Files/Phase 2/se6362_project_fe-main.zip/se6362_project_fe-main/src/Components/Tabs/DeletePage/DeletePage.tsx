import { BACKEND_URL, KWIC_DELETER, KWIC_ROUTE, KWIC_SEARCH_RESULTS } from "../../../Constants/backendroutes";
import { FETCH_POST_OPTIONS } from "../../../Constants/fetchCallHeaders";
import InputBar from "../../../Utility/InputBar/InputBar";
import { useState } from "react";
import { KEYWORD_OPERATOR, SORTING_METHOD } from "../Search/SearchPage";
import './DeletePage.css';

interface DeletePageProps {

}

const DeletePage: React.FC<DeletePageProps> = (_props: DeletePageProps) => {

  const [errorText, setErrorText] = useState<string>("");
  const [inputValue, setInputValue] = useState<string>("");
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [hasChangedInput, setHasChangedInput] = useState<boolean>(false);
  const [hasSubmittedDeleteRequest, setHasSubmittedDeleteRequest] = useState<boolean>(false);
  const [hasReceivedResponse, setHasReceivedResponse] = useState<boolean>(false);

  const handleInputChanged = (e: React.ChangeEvent) => {
    setInputValue((e.target as any).value);
    setHasChangedInput(true);
  }

  const getSearchResults = async (): Promise<string[]> => {
    const res = await fetch(BACKEND_URL + KWIC_ROUTE + KWIC_SEARCH_RESULTS, {
      method: "POST", 
      body: JSON.stringify({
        searchString: inputValue, 
        useCaseSensitive: false, 
        keywordOperator: KEYWORD_OPERATOR.AND, 
        sortingMethod: SORTING_METHOD.ALPHABETICAL, 
        reverseSort: false, 
      }), 
      ...FETCH_POST_OPTIONS, 
    }).then((res) => res.json());
    
    setHasChangedInput(false);
    return res;
  }

  const handleSearchClicked = async (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
    }
    setHasSubmittedDeleteRequest(false);
    setHasReceivedResponse(false);
    if (inputValue.length > 0) {
      if (hasChangedInput) {
        const results = await getSearchResults();
        setSearchResults(results);
      }
    }
    else {
      setSearchResults([]);
    }
  }

  const handleDeleteClicked = async (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
    }
    if ((inputValue.length <= 0) || hasChangedInput) {
      return;
    }

    let checkedValues: string[] = [];
    const formInputs: any = document.forms["DeleteForm" as any]["DeleteEntry"];
    //check whether there are multiple input elements
    if (formInputs instanceof RadioNodeList) {
      //there are multiple checkboxes
      checkedValues = Array.from(document.forms["DeleteForm" as any]["DeleteEntry"]).filter((elem: any) => elem.checked).map((elem: any) => elem.value);
    }
    else {
      //there is one checkbox
      if (document.forms["DeleteForm" as any]["DeleteEntry"].checked) {
        checkedValues = [document.forms["DeleteForm" as any]["DeleteEntry"].value];
      }
    }
    
    console.log("Deleting URLs: ", checkedValues);

    if (checkedValues.length <= 0) {
      return;
    }
    
    try {
      setHasSubmittedDeleteRequest(true);
      const result = await fetch(BACKEND_URL + KWIC_ROUTE + KWIC_DELETER, {
        method: "POST", 
        body: JSON.stringify({
          searchString: inputValue, 
          urls: checkedValues
        }), 
        ...FETCH_POST_OPTIONS, 
      }).then((res) => res.json());
      setHasReceivedResponse(true);

      if (result.status === 200) {
        setErrorText(result);
      }
      else {
        console.log(result);
      }
      
      // window.location.reload();
      
      const updatedResults = await getSearchResults();
      setSearchResults(updatedResults);
      setHasReceivedResponse(false);
      setHasSubmittedDeleteRequest(false);
    }
    catch (e) {
      setHasSubmittedDeleteRequest(false);
      setHasReceivedResponse(false);
      console.error(e);
    }
  }

  return (
    <div className="flexColumn fullHeight fullWidth overflowAuto">
      <p className="Delete_ErrorText">
        {errorText}
      </p>
      <form className="DeleteSearchForm flexColumn fullWidth padding1 borderBox gap1" onSubmit={handleSearchClicked}>
        <InputBar
          containerClassName={"DeleteSearchForm_Input"}
          labelText="Search for entry to delete"
          inputOnChange={handleInputChanged}
          inputValue={inputValue}
          inputPlaceholder="enter keyword to find"
          buttonText="Search"
          buttonClassName="DeleteSearchFForm_Input_Button"
          buttonOnClick={handleSearchClicked}
        />
        </form>
        <form name="DeleteForm" className="DeleteForm flexColumn fullWidth padding1 borderBox " onSubmit={handleDeleteClicked}>
        {
          searchResults.length > 0 && 
          <div className="DeleteForm_Content padding1 border borderRadius fullWidth borderBox ">
            <p className="DeleteForm_HeaderText textAlignCenter padding1">
              Select Entries to Delete
            </p>
            <div className="DeleteForm_URLOptionsDiv">
              {searchResults.map((searchResult: string, index: number) => {
                return (
                  <label className="DeleteForm_URLOptions_Label flexRow gap1" key={index}>
                    <input className="DeleteForm_URLOptions_Checkbox" type="checkbox" value={searchResult} name={"DeleteEntry"}/>
                    {searchResult}
                  </label>
                )
              })}
            </div>
          </div>
        }
        <div className="DeleteForm_ButtonDiv flexRow fullWidth centerJustify padding1 borderBox">
          {!hasChangedInput && inputValue.length > 0 && searchResults.length > 0 && !(hasReceivedResponse || hasSubmittedDeleteRequest) &&
            <button className="DeleteForm_Button button wideButton">
              Delete Entry
            </button>
          }
        </div>
      </form>
    </div>
    
  );
}

export default DeletePage;