import './Window.css';

interface WindowProps {
  children?: React.ReactNode, 
  sizingClassName?: string, 
  stylingClassName?: string, 
  title?: string, 
  titleClassName?: string, 
}

const Window: React.FC<WindowProps> = (props: WindowProps) => {

  return (
    <div className={"Window flexColumn " + (props.sizingClassName ?? "")}>
      {props.title && props.title.length > 0 && 
        <p className="Window_Title fullWidth textAlignCenter">
          {props.title}
        </p>
      }
      <div className={"Window_Content borderBox border flexGrow1 fullWidth overflowAuto " + props.stylingClassName}>
        {props.children}
      </div>
    </div>
  );
}

export default Window;