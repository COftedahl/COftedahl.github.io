import './Paginator.css'

interface PaginatorProps {
  className?: string, 
  numbersClassName?: string, 
  numbersContainerClassName?: string, 
  items: React.ReactNode[], 
  itemsPerPage?: number, 
  setItemsPerPage?: (newNumItems: number) => void,
  currentPage: number, 
  pageChange: (newPage: number) => void, 
}

const Paginator: React.FC<PaginatorProps> = (props: PaginatorProps) => {

  return (
    <div className={"PaginatorDiv border borderRadius padding1 borderBox" + (props.className || "")}>
      {
        props.items.filter((_item: React.ReactNode, index: number) => 
          (index >= ((props.currentPage - 1) * (props.itemsPerPage || 1))) && (index < ((props.currentPage) * (props.itemsPerPage || 1)))
        )
      }
      <hr className="Paginator_ContentNumbersDivider divider"/>
      <div className={"Paginator_NumbersDiv flexRow " + (props.numbersContainerClassName || "")}>
        {
          props.setItemsPerPage !== undefined && 
          <label className="Paginator_Numbers_ItemsPerPage_Label flexColumn centerAlign ">
            <p>
              Items per Page
            </p>
            <input type="number" className="Paginator_Numbers_ItemsPerPage_Input textAlignCenter" size={3} min={1} value={props.itemsPerPage} onChange={(e: React.ChangeEvent) => props.setItemsPerPage && props.setItemsPerPage((e.target as any).value)}/>
          </label>
        }
        {
          props.items.length > 0 
          ? 
          Array.from({length: Math.ceil((props.items.length * 1.0) / (props.itemsPerPage || 1))}, (_value: undefined, key: number) => key).map((index: number) => {
            return (
              <button 
                type="button" 
                key={index} 
                className={"Paginator_NumberButton button " + (props.numbersClassName || "") + (index === props.currentPage - 1 ? "Paginator_NumberButton-active" : "")} 
                onClick={() => props.pageChange(index + 1)}
              >
                {index + 1}
              </button>
            )
          })
          : 
          <p>
            No items to display
          </p>
        }
      </div>
    </div>
  );
}

export default Paginator;