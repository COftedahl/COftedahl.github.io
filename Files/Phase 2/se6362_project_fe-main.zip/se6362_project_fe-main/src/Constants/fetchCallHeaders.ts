export const FETCH_POST_OPTIONS = {
  headers: {
    "Content-Type": "application/json",
  }
}