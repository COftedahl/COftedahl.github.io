export const SEARCH_LOAD_WAIT_DURATION: number = 500;
export const SEARCH_TIMEOUT_DURATION: number = 5000;