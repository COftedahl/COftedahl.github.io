export const lineDelimiter: string = "\n";
export const lineDelimiterReplacementText: RegExp = /\\n/g;
export const lineDelimiterText: string = "\\n";
export const wordDelimiter: string = " ";